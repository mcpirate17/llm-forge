#!/usr/bin/env bash
set -euo pipefail
repo=/home/tim/Projects/llm-forge
old=b40b79ad42c9188fba9f3cf4ac09e6f637fa0de9
new=af62ae016a705f57e2f0bc7de2b89ef323af14a9
out=/tmp/forge-native-metrics/af62ae0-archive-evidence
prior=$(realpath -- "$(dirname -- "${BASH_SOURCE[0]}")/prior-b40b79a-python-tests.tsv")
remaining=$(realpath -- "$(dirname -- "${BASH_SOURCE[0]}")/remaining-python-tests.tsv")
retired=/tmp/forge-native-metrics/af62ae0-retired-python-tests.tsv
expected=/tmp/forge-native-metrics/af62ae0-expected-retired-paths.txt
cat > "$expected" <<'PATHS'
src/conductor/candidate_review/test_native_test_selection.py
src/conductor/candidate_review/test_receipt_scope.py
src/conductor/test_complete_scope_drift.py
src/conductor/test_local_ai_policy.py
src/conductor/test_policy_path.py
src/conductor/test_sandbox.py
PATHS
cd "$repo"
git diff --name-only "$old" "$new" -- '*.py' > /tmp/forge-native-metrics/af62ae0-changed-python-paths.txt
cmp "$expected" /tmp/forge-native-metrics/af62ae0-changed-python-paths.txt
awk -F '\t' 'NR==1 || $6 !~ /^src\/conductor\/(candidate_review\/(test_native_test_selection|test_receipt_scope)|test_(complete_scope_drift|local_ai_policy|policy_path|sandbox))\.py$/' "$prior" > /tmp/forge-native-metrics/af62ae0-inventory-rederived.tsv
cmp "$remaining" /tmp/forge-native-metrics/af62ae0-inventory-rederived.tsv
awk -F '\t' 'NR==1 || $6 ~ /^src\/conductor\/(candidate_review\/(test_native_test_selection|test_receipt_scope)|test_(complete_scope_drift|local_ai_policy|policy_path|sandbox))\.py$/' "$prior" > "$retired"
tail -n +2 "$retired" | cut -f6 > /tmp/forge-native-metrics/af62ae0-retired-inventory-paths.txt
cmp "$expected" /tmp/forge-native-metrics/af62ae0-retired-inventory-paths.txt
tr '\0' '\n' < "$out/test-source.paths0" | rg '\.py$' | sort > /tmp/forge-native-metrics/af62ae0-manifest-python.txt
tail -n +2 "$remaining" | cut -f6 | sort > /tmp/forge-native-metrics/af62ae0-inventory-python.txt
cmp /tmp/forge-native-metrics/af62ae0-manifest-python.txt /tmp/forge-native-metrics/af62ae0-inventory-python.txt
n=0
while IFS=$'\t' read -r category named expanded dynamic physical path parse_error; do
  [[ "$category" == category ]] && continue
  [[ "$(git rev-parse "$old:$path")" == "$(git rev-parse "$new:$path")" ]]
  n=$((n+1))
done < "$remaining"
[[ "$n" == 79 ]]
{
  printf 'commit=%s\n' "$new"
  printf 'python_test_manifest_paths=%s/%s\n' "$n" "$n"
  printf 'surviving_python_blob_oids_vs_b40b79a=%s/%s\n' "$n" "$n"
  printf 'surviving_inventory_rows_from_prior_verified_pin=%s/%s\n' "$n" "$n"
  printf 'retired_executable_suites=6 named=53 static_expanded=63 physical_lines=1007\n'
  awk -F '\t' 'NR>1 {c[$1]++; n[$1]+=$2; e[$1]+=$3; p[$1]+=$5} END {for (k in c) printf "%s: files=%d named=%d static_expanded=%d physical_lines=%d\n", k,c[k],n[k],e[k],p[k]}' "$remaining" | sort
} > "$out/python-inventory-verification.txt"
