Pinned native source SLOC measurement
=====================================

Source commit: 1f4459ceb368eb495068032f61fe6d83bc133509
Tree object: ee385384a5660f02962084e0a1a7693946b82732
Git archive stream SHA-256: bdbd6acdbe6ef5ec938b172863aac919da12e276ae11201bf9990ab99eb77ff5

This measures tracked Python, Rust, and shell source at the pinned commit,
using the unchanged path classification, Tokei 15.0.0, and syn-based
original-minus-masked inline Rust test treatment. It excludes current dirty
work. These percentages describe source composition, not runtime coverage,
behavioral coverage, or performance.

Production: Python 51,610 code lines; Rust 52,949; shell 194; native 50.5465%.
Tests: Python 23,449 code lines; Rust 78,795; Rust 77.0656%.
All tracked source including examples: Python 75,059; Rust 131,843; shell 194;
native 63.6627%.
Manifests: 375 production paths, 331 test paths, 708 counted source paths.
Two Rust example files with 99 code lines belong only to the all-source view.

The splitter found 100 test-only ranges in 85 production Rust files. Tokei
counts 43,180 Rust code lines in those original files and 30,121 after
masking, a 13,059-line test delta. Production Rust is 66,008 raw minus
13,059 inline-test lines = 52,949. Separate Rust test paths have 65,736
lines; adding the inline delta yields 78,795 Rust test lines.

Run the included measure-pinned.sh with the exact commit. It writes its
intermediates under /tmp/forge-native-metrics/1f4459c-archive-evidence.
The included verify-1f4459c.py independently classifies git ls-tree paths,
fetches every counted source with git cat-file --batch, checks SHA-256 and
archive bytes, re-runs the syn splitter on a separate archive extraction,
compares all 100 ranges and 85 masked/extracted copies, and re-runs Tokei
for every scope and per-file report. Its result is in
independent-verification.txt. Tokei's report array order varies, so reports
are compared by path and stats.

The archive includes NUL-delimited path manifests, all source hashes, exact
archive hash, raw Tokei JSON, AST ranges and counts, splitter source and
lockfile, both scripts, and executable/tool hashes. The source snapshot and
inline source copies are intentionally excluded; retrieve source by commit.

For independent reproduction, first run measure-pinned.sh to populate the
first evidence directory, then create a second extraction:

    mkdir -p /tmp/forge-native-metrics/1f4459c-independent/source
    git archive 1f4459ceb368eb495068032f61fe6d83bc133509 | tar -x -C /tmp/forge-native-metrics/1f4459c-independent/source
    python verify-1f4459c.py

The script uses the pinned tool paths recorded in tool-versions.txt and fails
on any manifest, blob, Tokei, splitter, or arithmetic mismatch.
