Pinned native source SLOC measurement
=====================================

Source commit: 6dd9fc8d31daab114cf856b744ceb20d64cdd7a3
Tree object: ecb39e753a9ee21fd03339c3d908762e0cb27a3e
Git archive stream SHA-256: e085251f99a80bbf3a6ee0489b4abb79a91e2458d3989c180682cb131f5ad58e

This measures tracked Python, Rust, and shell source at the pinned commit,
using the unchanged path classification, Tokei 15.0.0, and syn-based
original-minus-masked inline Rust test treatment. It excludes current dirty
work. These percentages describe source composition, not runtime coverage,
behavioral coverage, or performance.

Production: Python 51,610 code lines; Rust 52,951; shell 194; native 50.5475%.
Tests: Python 22,573 code lines; Rust 80,835; Rust 78.1709%.
All tracked source including examples: Python 74,183; Rust 133,885; shell 194;
native 64.2868%.
Manifests: 375 production paths, 336 test paths, 713 counted source paths.
Two Rust example files with 99 code lines belong only to the all-source view.

The splitter found 100 test-only ranges in 85 production Rust files. Tokei
counts 43,180 Rust code lines in those original files and 30,121 after
masking, a 13,059-line test delta. Production Rust is 66,010 raw minus
13,059 inline-test lines = 52,951. Separate Rust test paths have 67,776
lines; adding the inline delta yields 80,835 Rust test lines.

Run the included measure-pinned.sh with the exact commit. It writes its
intermediates under /tmp/forge-native-metrics/6dd9fc8-archive-evidence.
The included verify-6dd9fc8.py independently classifies git ls-tree paths,
fetches every counted source with git cat-file --batch, checks SHA-256 and
archive bytes, re-runs the syn splitter on a separate archive extraction,
compares all 100 ranges and 85 masked/extracted copies, and re-runs Tokei
for every scope and per-file report. Its result is in
independent-verification.txt. Tokei's report array order varies, so reports
are compared by path and stats.

The archive includes NUL-delimited path manifests, all source hashes, exact
archive hash, raw Tokei JSON, AST ranges and counts, splitter source and
lockfile, both scripts, and executable/tool hashes. The source snapshot and
inline source copies are intentionally excluded; retrieve source by commit.

For independent reproduction, first run measure-pinned.sh to populate the
first evidence directory, then create a second extraction:

    mkdir -p /tmp/forge-native-metrics/6dd9fc8-independent/source
    git archive 6dd9fc8d31daab114cf856b744ceb20d64cdd7a3 | tar -x -C /tmp/forge-native-metrics/6dd9fc8-independent/source
    python verify-6dd9fc8.py

The script uses the pinned tool paths recorded in tool-versions.txt and fails
on any manifest, blob, Tokei, splitter, or arithmetic mismatch.
