Pinned native-migration measurement evidence

Source commit: b2ec44f7cbb9c2f6eb42960e0c710fc4cc3e0169
Git archive stream SHA-256: eb5864447e7bdb6ccf99e48d2c5fa0b5724614c5a40543d60bddb58f66b402aa
All 668 source paths in the manifests were independently checked against their Git blobs; mismatches: 0.

The manifests include tracked implementation sources ending in .py, .rs, or .sh,
excluding documentation, research, build output, dependencies, and examples from
the production denominator. Separate tests are classified by tests/testdata paths
and the documented Python/Rust filename rules. The two Rust example files contribute
99 SLOC to all-source only.

Production: Python 51,300; Rust 51,569; shell 194; native share 50.0364%.
Tests: Python 40,566; separate Rust 28,261; inline Rust 13,059; total Rust 41,320;
Rust test share 50.4604%.

Inline Rust tests are measured additively as Tokei(original full Rust files) minus
Tokei(the same files with test-only AST ranges masked in place). This preserves
Tokei comment classification. The splitter found 100 ranges in 85 production
Rust files: 42,894 original code lines minus 29,835 masked lines = 13,059.

Reproduce from the repository checkout with:

  /tmp/forge-native-metrics/measure-pinned.sh b2ec44f7cbb9c2f6eb42960e0c710fc4cc3e0169

The reproduction script expects Tokei 15.0.0 and the compiled splitter identified
in tool-versions.txt. This archive intentionally omits the extracted source tree
and inline-prod/inline-test scratch directories.
