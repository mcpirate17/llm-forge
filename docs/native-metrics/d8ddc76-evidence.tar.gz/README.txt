Pinned native source SLOC measurement
====================================

Source commit: d8ddc76cbebb2e6a321d1a758b3f6fd423a2714b
Tree object: f8bcc5d7eac0e90fdd93d8c93b53a65044b2ac5f
Tracked Python, Rust, and shell source was measured from a Git archive using
unchanged path classification, Tokei 15.0.0, and AST inline-test treatment.
These are source composition metrics, not runtime coverage, behavioral
coverage, or performance claims. Dirty native API, graph-selection, and
active-state/session-close work is excluded from the committed snapshot.

Counts
------

Production: Python 51,296; Rust 52,303; shell 194; native share 50.3916%.
Tests: Python 32,080; Rust 58,105; Rust share 64.4287%.
All tracked source including examples: Python 83,376; Rust 110,507; shell
194. Manifests: 372 production files, 299 test files, 673 source files total.
The all-source view includes two Rust example files totaling 99 code lines;
they are excluded from production and test scopes.

The splitter identified 100 test-only Rust item ranges in 85 production Rust
files. Inline tests use the original-minus-masked delta: 43,180 original
inline-file Rust code lines minus 30,121 masked production Rust code lines
= 13,059. Production Rust is 65,362 raw lines minus 13,059 = 52,303. Rust
tests are 45,046 separate Rust lines plus the same 13,059 inline lines
= 58,105.

Reproduction and verification
-----------------------------

Run the included measurement script with the exact commit:

    ./measure-pinned.sh d8ddc76cbebb2e6a321d1a758b3f6fd423a2714b

The script writes intermediates under
`/tmp/forge-native-metrics/d8ddc76-archive-evidence`. It obtains tracked paths
from Git, measures raw Tokei 15.0.0 JSON, and attributes inline Rust tests
from original-minus-masked Rust files. The Cargo manifest, lockfile, splitter
source, and tool hashes identify the AST parser and Tokei inputs.

An independent `git ls-tree` classifier reproduced all three manifests. All
673 counted source blobs were fetched with `git cat-file blob`, SHA-256
checked against the published per-file list, and compared byte-for-byte to
the extracted Git archive. The Git archive stream SHA-256 is recorded in
`archive-stream.sha256`. A separate splitter run reproduced all 100 ranges,
85 masked and extracted file copies, and its summary. A separate Tokei run
reproduced every per-file report and the count arithmetic; report ordering
and temporary-path prefixes were normalized for comparison. The detailed
check status is in `independent-verification.txt`.

Evidence contents
-----------------

This package contains raw Tokei JSON for production, tests, all source,
original inline Rust files, and masked production Rust; NUL-delimited path
manifests; source hashes; AST ranges; count summaries; tool versions and
executable hashes; the splitter source and lockfile; the reproduction script;
and this README. The extracted source snapshot and inline source-copy folders
are excluded. Retrieve source from Git by commit ID.
