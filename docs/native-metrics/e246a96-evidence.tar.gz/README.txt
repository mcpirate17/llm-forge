Pinned source-composition evidence for e246a964d481215beede5c9cf2cb9531804aa9e0.

measure-pinned.sh reproduces the unchanged path classification and Tokei 15.0.0
plus syn inline-test split from a plain Git archive. verify-pinned.sh checks a
second archive extraction, every counted path against its Git blob, all source
hashes, every classified manifest, AST ranges and 87 masked Rust file copies,
per-file Tokei reports, and raw count arithmetic. Run it with bash; it writes
scratch output to /tmp/forge-native-metrics and does not mutate the checkout.
The source and masked copies are omitted here because they regenerate from Git.

The four committed migration-map documents contain 197 original-to-Rust rows:
195 cases from six retired Python suites and two hook corpus cases whose Python
provider remains. The source diff, prior suite inventory, maps, and source
hashes bind the cohort. Seven new Python files under the equivalence-probe
fixture directory are input programs, counted in test Python SLOC; they are not
Rust and do not add executable Python test suites.

Scoped logs show 54 CPU-embed, 34 equivalence-probe, 26 mutation-generate,
32 mutation-retention, 17 workspace-hygiene, 32 worktree-reap, and two hook
corpus Rust tests passing. The discovery target passed 32 cases and scoped
Clippy passed. A separate workspace parity target passed 15. These are scoped
checks, not the required full clean-tree local gate.

No matched performance experiment ran for this cohort. The older 134-case
paired harness result is pinned to 8d71bca and cannot establish speed for
this source. The last prior full gate was on 415ae7c, not this commit.
