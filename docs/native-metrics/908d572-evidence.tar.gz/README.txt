Pinned native source SLOC measurement
====================================

Source commit: 908d572d3e4cbfe646c4e0e888f0a0853b7df751
Tree object: c0d47c5a4ab3029a568ae85a38fe507f844e484c
Tracked Python, Rust, and shell source was measured from a Git archive using
the unchanged path classification and AST inline-test treatment. These are
source composition metrics, not runtime coverage, behavioral coverage, or
performance claims. Dirty graph-selection and communication test ports were
not included in the committed snapshot.

Counts
------

Production: Python 51,296; Rust 52,303; shell 194; native share 50.3916%.
Tests: Python 33,391; Rust 55,171; Rust share 62.2965%.
All tracked source including examples: Python 84,687; Rust 107,573; shell
194. Manifests: 372 production files, 296 test files, 670 source files total.
The all-source view includes two Rust example files totaling 99 code lines;
they are excluded from production and test scopes.

The splitter identified 100 test-only Rust item ranges in 85 production Rust
files. Inline tests use the original-minus-masked delta: 43,180 original
inline-file Rust code lines minus 30,121 masked production Rust code lines
= 13,059. Production Rust is 65,362 raw lines minus 13,059 = 52,303. Rust
tests are 42,112 separate Rust lines plus the same 13,059 inline lines
= 55,171.

Reproduction and verification
-----------------------------

Run the included measurement script with the exact commit:

    ./measure-pinned.sh 908d572d3e4cbfe646c4e0e888f0a0853b7df751

The script writes intermediates under
`/tmp/forge-native-metrics/908d572-archive-evidence`. It obtains tracked paths
from Git, measures raw Tokei 15.0.0 JSON, and attributes inline Rust tests
from original-minus-masked Rust files. The Cargo manifest, lockfile, splitter
source, and tool hashes identify the AST parser and Tokei inputs.

An independent `git ls-tree` classifier reproduced all three manifests. All
670 counted source blobs were fetched with `git cat-file --batch`, SHA-256
checked against the published per-file list, and compared byte-for-byte to
the extracted Git archive. The Git archive stream SHA-256 is recorded in
`archive-stream.sha256`. A separate splitter run reproduced all 100 ranges,
85 masked and extracted file copies, and its summary. A separate Tokei run
reproduced every per-file report and the count arithmetic; report ordering and
temporary-path prefixes were normalized for comparison. The detailed check
status is in `independent-verification.txt`.

Evidence contents
-----------------

This package contains raw Tokei JSON for production, tests, all source,
original inline Rust files, and masked production Rust; NUL-delimited path
manifests; source hashes; AST ranges; count summaries; tool versions and
executable hashes; the splitter source and lockfile; the reproduction script;
and this README. The extracted source snapshot and inline source-copy
folders are excluded. Retrieve source from Git by commit ID.
