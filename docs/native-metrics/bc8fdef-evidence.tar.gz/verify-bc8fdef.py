import hashlib
import io
import json
import subprocess
from pathlib import Path

REPO = Path('/home/tim/Projects/llm-forge')
REV = 'bc8fdefa1ed6fcc405d3b90237489a89883317fe'
FIRST = Path('/tmp/forge-native-metrics/bc8fdef-archive-evidence')
SECOND = Path('/tmp/forge-native-metrics/bc8fdef-independent')
TOOL = Path('/tmp/forge-native-metrics/bin/tokei')
SPLIT = Path('/tmp/forge-native-metrics/syn-split/target/release/forge-native-metric-split')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(*args, cwd=REPO, input_data=None):
    p = subprocess.run(args, cwd=cwd, input=input_data, capture_output=True, check=True)
    return p.stdout

def classified(path):
    if not path.endswith(('.py', '.rs', '.sh')):
        return None
    if path.startswith(('docs/', 'research/', 'target/', 'build/', 'dist/', '.venv/')):
        return None
    if any('/' + part + '/' in '/' + path + '/' for part in ('target', 'build', 'dist', '.venv')):
        return None
    parts = path.split('/')
    is_test = 'tests' in parts or 'testdata' in parts
    name = parts[-1]
    is_test |= name.startswith('test_') and name.endswith('.py')
    is_test |= name.endswith(('_test.py', '_tests.rs')) or name in ('conftest.py', 'tests.rs')
    if is_test:
        return 'test'
    if path.startswith('native/forge/examples/'):
        return 'example'
    return 'production'

raw = run('git', 'ls-tree', '-r', '-z', REV)
entries = []
for row in raw.split(b'\0'):
    if not row:
        continue
    meta, path_raw = row.split(b'\t', 1)
    mode, typ, oid = meta.split(b' ')
    path = path_raw.decode()
    entries.append((mode.decode(), typ.decode(), oid.decode(), path))
tracked = b''.join(path.encode() + b'\0' for _, _, _, path in entries)
assert tracked == (FIRST / 'tracked.paths0').read_bytes()
classes = {'production': [], 'test': [], 'example': []}
for mode, typ, oid, path in entries:
    category = classified(path)
    if category:
        assert mode == '100644' or mode == '100755', (path, mode)
        assert typ == 'blob'
        classes[category].append((oid, path))
for name, paths in [
    ('production-source.paths0', [path for _, path in classes['production']]),
    ('test-source.paths0', [path for _, path in classes['test']]),
    ('all-source.paths0', [path for _, path in classes['production'] + classes['test'] + classes['example']]),
]:
    expected_set = set(paths)
    actual = (FIRST / name).read_bytes().split(b'\0')
    actual_set = {part.decode() for part in actual if part}
    assert expected_set == actual_set, name
    assert len(expected_set) == len(actual_set)
# The all-source manifest follows tree ordering, not grouped scope order.
all_paths = [path for _, _, _, path in entries if classified(path)]
assert (FIRST / 'all-source.paths0').read_bytes() == b''.join(p.encode()+b'\0' for p in all_paths)
for category, filename in [('production', 'production-source.paths0'), ('test', 'test-source.paths0')]:
    paths = [path for _, path in classes[category]]
    assert (FIRST / filename).read_bytes() == b''.join(p.encode()+b'\0' for p in paths)

source_rows = {}
for line in (FIRST / 'source-content-sha256.txt').read_text().splitlines():
    digest, path = line.split('  ', 1)
    source_rows[path] = digest
assert len(source_rows) == len(all_paths) == 688
batch = run('git', 'cat-file', '--batch', input_data=''.join(oid+'\n' for _, _, oid, path in entries if classified(path)).encode())
stream = io.BytesIO(batch)
checked = 0
for mode, typ, oid, path in entries:
    if not classified(path):
        continue
    header = stream.readline().decode().strip().split()
    assert header[:2] == [oid, 'blob'], (path, header)
    content = stream.read(int(header[2]))
    assert stream.read(1) == b'\n'
    digest = sha(content)
    assert source_rows[path] == digest, path
    assert (FIRST / 'source' / path).read_bytes() == content, path
    assert (SECOND / 'source' / path).read_bytes() == content, path
    checked += 1
assert stream.read() == b''

prod = SECOND / 'production.paths0'
prod.write_bytes((FIRST / 'production-source.paths0').read_bytes())
outprod = SECOND / 'inline-prod'
outtest = SECOND / 'inline-test'
result = run(str(SPLIT), str(SECOND / 'source'), str(prod), str(outprod), str(outtest), str(SECOND / 'inline-ranges.tsv'), cwd=SECOND)
assert result.decode().strip() == (FIRST / 'split-summary.txt').read_text().strip()
assert (SECOND / 'inline-ranges.tsv').read_bytes() == (FIRST / 'inline-ranges.tsv').read_bytes()
for folder in ('inline-prod', 'inline-test'):
    left = FIRST / folder
    right = SECOND / folder
    first = {p.relative_to(left) for p in left.rglob('*.rs')}
    second = {p.relative_to(right) for p in right.rglob('*.rs')}
    assert first == second and len(first) == 85
    for rel in first:
        assert (left / rel).read_bytes() == (right / rel).read_bytes(), (folder, rel)

def report(path):
    return json.loads(path.read_text())

def normalize(payload, prefix=None):
    result = {}
    for language, block in payload.items():
        if language == 'Total':
            result[language] = {k:v for k,v in block.items() if k not in ('reports', 'children')}
            continue
        files = {}
        for row in block.get('reports', []):
            name = row['name']
            if prefix:
                name = name.removeprefix(str(prefix) + '/')
            files[name] = row['stats']
        result[language] = {k:v for k,v in block.items() if k not in ('reports', 'children')}
        result[language]['reports'] = files
    return result

for manifest, output in [
    ('production-source.paths0', 'production-raw-tokei.json'),
    ('test-source.paths0', 'test-raw-tokei.json'),
    ('all-source.paths0', 'all-raw-tokei.json'),
    ('inline-rust-paths.paths0', 'inline-original-tokei.json'),
]:
    paths = [p.decode() for p in (FIRST / manifest).read_bytes().split(b'\0') if p]
    current = json.loads(run(str(TOOL), '--no-ignore', '--output', 'json', *paths, cwd=SECOND / 'source'))
    assert normalize(current) == normalize(report(FIRST / output)), output
masked = [str(p) for p in sorted(outprod.rglob('*.rs'))]
current = json.loads(run(str(TOOL), '--no-ignore', '--output', 'json', *masked, cwd=SECOND / 'source'))
assert normalize(current, outprod) == normalize(report(FIRST / 'inline-masked-prod-tokei.json'), FIRST / 'inline-prod'), 'masked'

m = dict(line.split('=',1) for line in (FIRST / 'metrics.txt').read_text().splitlines())
assert int(m['production_files']) == len(classes['production']) == 375
assert int(m['test_files']) == len(classes['test']) == 311
assert int(m['all_source_files']) == len(all_paths) == 688
assert len(classes['example']) == 2
prod_raw = report(FIRST / 'production-raw-tokei.json')
test_raw = report(FIRST / 'test-raw-tokei.json')
all_raw = report(FIRST / 'all-raw-tokei.json')
inline_orig = report(FIRST / 'inline-original-tokei.json')['Rust']['code']
inline_mask = report(FIRST / 'inline-masked-prod-tokei.json')['Rust']['code']
inline = inline_orig - inline_mask
assert (inline_orig, inline_mask, inline) == (43180, 30121, 13059)
assert int(m['production_python']) == prod_raw['Python']['code']
assert int(m['production_rust_inline_raw']) == prod_raw['Rust']['code']
assert int(m['production_shell']) == prod_raw['Shell']['code']
assert int(m['production_rust']) == prod_raw['Rust']['code'] - inline
assert int(m['test_python']) == test_raw['Python']['code']
assert int(m['test_rust_separate']) == test_raw['Rust']['code']
assert int(m['test_rust']) == test_raw['Rust']['code'] + inline
assert int(m['all_python']) == all_raw['Python']['code'] == prod_raw['Python']['code']+test_raw['Python']['code']
assert int(m['all_rust']) == all_raw['Rust']['code'] == prod_raw['Rust']['code']+test_raw['Rust']['code']+99
assert int(m['all_shell']) == all_raw['Shell']['code'] == prod_raw['Shell']['code']
assert m['production_native_percent'] == f"{100*int(m['production_rust'])/(int(m['production_python'])+int(m['production_rust'])+int(m['production_shell'])):.4f}"
assert m['test_rust_percent'] == f"{100*int(m['test_rust'])/(int(m['test_python'])+int(m['test_rust'])):.4f}"
print(f'independently_verified_git_blobs={checked}')
print(f'source_sha256_checks={checked}/{checked}')
print(f'archive_blob_byte_checks={checked}/{checked}')
print(f'classified_source_paths={len(all_paths)}')
print(f'production_paths={len(classes["production"])}')
print(f'test_paths={len(classes["test"])}')
print(f'example_paths={len(classes["example"])}')
print('tracked_and_classification_manifests=exact')
print('independent_tokei_per_file_reports=exact')
print('independent_ast_split_ranges=exact')
print('independent_inline_source_copies=85/85')
print('independent_raw_count_arithmetic=exact')
