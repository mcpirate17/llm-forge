Pinned native source SLOC measurement
====================================

Source commit: bc8fdefa1ed6fcc405d3b90237489a89883317fe
Tree object: e5f03aa789d815fbbc30c5bdf353c644f248a6a4
Git archive stream SHA-256: 6c2ef14d62afee7b2f1ec0f241dbb3c2edac83109873b3e5af0795666204fb0c

This measures tracked Python, Rust, and shell source at the pinned commit,
using the unchanged path classification, Tokei 15.0.0, and syn-based
original-minus-masked inline Rust test treatment. It excludes current dirty
work. These percentages describe source composition, not runtime coverage,
behavioral coverage, or performance.

Production: Python 51,610 code lines; Rust 52,909; shell 194; native 50.5276%.
Tests: Python 28,859 code lines; Rust 67,216; Rust 69.9620%.
All tracked source including examples: Python 80,469; Rust 120,224; shell 194;
native 59.8466%.
Manifests: 375 production paths, 311 test paths, 688 counted source paths.
Two Rust example files with 99 code lines belong only to the all-source view.

The splitter found 100 test-only ranges in 85 production Rust files. Tokei
counts 43,180 Rust code lines in those original files and 30,121 after
masking, a 13,059-line test delta. Production Rust is 65,968 raw minus
13,059 inline-test lines = 52,909. Separate Rust test paths have 54,157
lines; adding the inline delta yields 67,216 Rust test lines.

Run the included measure-pinned.sh with the exact commit. It writes its
intermediates under /tmp/forge-native-metrics/bc8fdef-archive-evidence.
The included verify-bc8fdef.py independently classifies git ls-tree paths,
fetches every counted source with git cat-file --batch, checks SHA-256 and
archive bytes, re-runs the syn splitter on a separate archive extraction,
compares all 100 ranges and 85 masked/extracted copies, and re-runs Tokei
for every scope and per-file report. Its result is in
independent-verification.txt. Tokei's report array order varies, so reports
are compared by path and stats.

The archive includes NUL-delimited path manifests, all source hashes, exact
archive hash, raw Tokei JSON, AST ranges and counts, splitter source and
lockfile, both scripts, and executable/tool hashes. The source snapshot and
inline source copies are intentionally excluded; retrieve source by commit.

For independent reproduction, first run measure-pinned.sh to populate the
first evidence directory, then create a second extraction:

    mkdir -p /tmp/forge-native-metrics/bc8fdef-independent/source
    git archive bc8fdefa1ed6fcc405d3b90237489a89883317fe | tar -x -C /tmp/forge-native-metrics/bc8fdef-independent/source
    python verify-bc8fdef.py

The script uses the pinned tool paths recorded in tool-versions.txt and fails
on any manifest, blob, Tokei, splitter, or arithmetic mismatch.
