Forge native source metrics evidence for commit 6ba68187ffedb4984f32f8f85b0c5a1370efefdc.

All counts are source code lines from Tokei 15.0.0, not behavioral coverage.
The source path classifier in measure-pinned.sh separates production, tests,
and two examples. Inline Rust test items are parsed with the pinned syn
splitter: 13,059 code lines are assigned to tests rather than production.

The original measurement used a clean git archive. A second git archive was
extracted, with its byte-identical repeated stream hash recorded in
archive-stream.sha256. verify-6ba6818.py independently checked the exact
classification/path manifests, 731 Git blob bytes and content hashes against
both archives, per-file Tokei JSON, all 100 inline AST ranges, all 85 masked
and extracted Rust file copies, and source-line arithmetic. The verifier's
output is independent-verification.txt. The archive source and generated
inline copies are intentionally omitted from this compact evidence package;
all source bytes can be recreated with the pinned Git commit.

metrics.txt contains the resulting production/test/all-source code counts.
tool-versions.txt, syn-split-source.rs, syn-split-Cargo.toml and
syn-split-Cargo.lock pin the measurement tools and splitting implementation.
source-content-sha256.txt and the NUL-separated manifests identify every
counted source file. The raw Tokei JSON files preserve per-file output.
