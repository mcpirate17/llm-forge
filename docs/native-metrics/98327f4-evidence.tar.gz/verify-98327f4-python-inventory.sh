#!/usr/bin/env bash
set -euo pipefail
repo=/home/tim/Projects/llm-forge
old=b0d8fced801aa6d85acf6b8e38de9c448a94b736
new=98327f462928f6d90142977c93c532d53f6c2f02
out=/tmp/forge-native-metrics/98327f4-archive-evidence
bundle=$(realpath -- "$(dirname -- "${BASH_SOURCE[0]}")")
prior="$bundle/prior-b0d8fce-python-tests.tsv"
remaining=/tmp/forge-native-metrics/98327f4-remaining-python-tests.tsv
retired=/tmp/forge-native-metrics/98327f4-retired-python-tests.tsv
expected=/tmp/forge-native-metrics/98327f4-expected-python-diff.txt
cat > "$expected" <<'PATHS'
D	src/conductor/test_current_work_guard.py
D	src/conductor/test_external_invariants.py
D	src/conductor/test_governance_identity.py
D	src/conductor/test_ownership_claim_expiry.py
D	src/conductor/test_radon_complexity.py
D	src/conductor/test_vulture_audit.py
PATHS
cd "$repo"
git diff --name-status "$old" "$new" -- '*.py' > /tmp/forge-native-metrics/98327f4-python-diff.txt
cmp "$expected" /tmp/forge-native-metrics/98327f4-python-diff.txt
awk -F '\t' 'NR==1 || $6 !~ /^src\/conductor\/test_(current_work_guard|external_invariants|governance_identity|ownership_claim_expiry|radon_complexity|vulture_audit)\.py$/' "$prior" > "$remaining"
awk -F '\t' 'NR==1 || $6 ~ /^src\/conductor\/test_(current_work_guard|external_invariants|governance_identity|ownership_claim_expiry|radon_complexity|vulture_audit)\.py$/' "$prior" > "$retired"
tr '\0' '\n' < "$out/test-source.paths0" | rg '\.py$' | sort > /tmp/forge-native-metrics/98327f4-manifest-python.txt
tail -n +2 "$remaining" | cut -f6 | sort > /tmp/forge-native-metrics/98327f4-inventory-python.txt
cmp /tmp/forge-native-metrics/98327f4-manifest-python.txt /tmp/forge-native-metrics/98327f4-inventory-python.txt
n=0
while IFS=$'\t' read -r category named expanded dynamic physical path parse_error; do
  [[ "$category" == category ]] && continue
  [[ "$(git rev-parse "$old:$path")" == "$(git rev-parse "$new:$path")" ]]
  [[ "$physical" == "$(wc -l < "$out/source/$path")" ]]
  n=$((n+1))
done < "$remaining"
[[ "$n" == 71 ]]
[[ "$(awk -F '\t' 'NR>1 {n+=$2;e+=$3;p+=$5;c++} END{print c,n,e,p}' "$retired")" == '6 93 99 1547' ]]
[[ "$(awk -F '\t' 'NR>1 && $1=="executable_test" {n+=$2;e+=$3;c++} END{print c,n,e}' "$remaining")" == '36 656 730' ]]
{
  printf 'commit=%s\n' "$new"
  printf 'python_test_manifest_paths=71/71\n'
  printf 'surviving_python_blob_oids_vs_b0d8fce=71/71\n'
  printf 'surviving_python_physical_lines=71/71\n'
  printf 'retired_executable_suites=6 named=93 static_expanded=99 physical_lines=1547\n'
  awk -F '\t' 'NR>1 {c[$1]++; n[$1]+=$2; e[$1]+=$3; p[$1]+=$5} END {for (k in c) printf "%s: files=%d named=%d static_expanded=%d physical_lines=%d\n", k,c[k],n[k],e[k],p[k]}' "$remaining" | sort
} > "$out/python-inventory-verification.txt"
