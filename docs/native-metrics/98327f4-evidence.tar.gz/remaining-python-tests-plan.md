# Remaining executable Python tests at 98327f4

Pinned commit: `98327f462928f6d90142977c93c532d53f6c2f02`. The source inventory is `/tmp/forge-remaining-python-tests.tsv`, copied from the deterministic evidence bundle `docs/native-metrics/98327f4-evidence.tar.gz`. It contains **36 executable suites, 656 named test functions, 730 statically expanded parameter cases, and 18,429 physical lines**. Another 34 Python fixture inputs and one shared conftest are separate categories in the TSV. These counts come from the archived source, not pytest collection or behavioral coverage.

Compared with verified `b0d8fce`, six executable suites were retired: `test_current_work_guard.py`, `test_external_invariants.py`, `test_governance_identity.py`, `test_ownership_claim_expiry.py`, `test_radon_complexity.py`, and `test_vulture_audit.py` (93 named and 99 statically expanded cases, 1,547 physical lines). All 71 surviving Python test blobs are byte-identical to the prior pin. Dirty checkout files and future draft targets are excluded.

## Executable suites

| Path | Named tests | Static cases | Physical lines |
| --- | ---: | ---: | ---: |
| `src/conductor/test_candidate_review.py` | 56 | 56 | 3110 |
| `src/conductor/test_candidate_review_call_and_evidence.py` | 19 | 39 | 560 |
| `src/conductor/test_candidate_review_claims_view.py` | 5 | 5 | 146 |
| `src/conductor/test_candidate_review_hardening.py` | 12 | 12 | 430 |
| `src/conductor/test_candidate_review_scan_coverage.py` | 6 | 6 | 190 |
| `src/conductor/test_ci_history_fetch.py` | 11 | 11 | 457 |
| `src/conductor/test_cpu_embed.py` | 53 | 54 | 797 |
| `src/conductor/test_crg_seed_worktree.py` | 7 | 7 | 271 |
| `src/conductor/test_doctor.py` | 25 | 34 | 368 |
| `src/conductor/test_equivalence_probe.py` | 34 | 34 | 991 |
| `src/conductor/test_gate.py` | 33 | 33 | 520 |
| `src/conductor/test_gate_policy_provenance.py` | 5 | 5 | 215 |
| `src/conductor/test_gate_rollout.py` | 23 | 23 | 433 |
| `src/conductor/test_guardrail_audit.py` | 22 | 27 | 474 |
| `src/conductor/test_guardrail_duplicates.py` | 9 | 14 | 153 |
| `src/conductor/test_installed_layout.py` | 1 | 1 | 123 |
| `src/conductor/test_mutation_attribution.py` | 20 | 26 | 673 |
| `src/conductor/test_mutation_campaign_generate.py` | 25 | 26 | 947 |
| `src/conductor/test_mutation_patch_audit.py` | 27 | 27 | 1407 |
| `src/conductor/test_mutation_retention.py` | 32 | 32 | 768 |
| `src/conductor/test_package_resources.py` | 16 | 23 | 506 |
| `src/conductor/test_probe_budget.py` | 11 | 11 | 439 |
| `src/conductor/test_receipt_verify.py` | 7 | 7 | 207 |
| `src/conductor/test_ref_aware_governance.py` | 8 | 8 | 221 |
| `src/conductor/test_run_duplicate_audit.py` | 25 | 31 | 819 |
| `src/conductor/test_runner_lineage.py` | 14 | 17 | 187 |
| `src/conductor/test_slop_gate.py` | 19 | 19 | 430 |
| `src/conductor/test_slop_ledger.py` | 16 | 16 | 330 |
| `src/conductor/test_snapshot_worktree.py` | 7 | 7 | 241 |
| `src/conductor/test_tooling_boundary.py` | 31 | 40 | 486 |
| `src/conductor/test_value_gate_scope.py` | 14 | 14 | 263 |
| `src/conductor/test_workspace_hygiene.py` | 17 | 17 | 345 |
| `src/conductor/test_worktree_lease.py` | 9 | 11 | 117 |
| `src/conductor/test_worktree_reap.py` | 32 | 32 | 497 |
| `src/conductor/test_worktree_runtime.py` | 3 | 3 | 152 |
| `src/tooling/hooks/claude/test_workspace_exposure_parity_corpus.py` | 2 | 2 | 156 |

## Smallest suites by physical lines

This size view can guide a bounded next-cohort audit; it does not establish replacement coverage, runtime safety, or ownership.

| Path | Named tests | Static cases | Physical lines |
| --- | ---: | ---: | ---: |
| `src/conductor/test_worktree_lease.py` | 9 | 11 | 117 |
| `src/conductor/test_installed_layout.py` | 1 | 1 | 123 |
| `src/conductor/test_candidate_review_claims_view.py` | 5 | 5 | 146 |
| `src/conductor/test_worktree_runtime.py` | 3 | 3 | 152 |
| `src/conductor/test_guardrail_duplicates.py` | 9 | 14 | 153 |
| `src/tooling/hooks/claude/test_workspace_exposure_parity_corpus.py` | 2 | 2 | 156 |
| `src/conductor/test_runner_lineage.py` | 14 | 17 | 187 |
| `src/conductor/test_candidate_review_scan_coverage.py` | 6 | 6 | 190 |
| `src/conductor/test_receipt_verify.py` | 7 | 7 | 207 |
| `src/conductor/test_gate_policy_provenance.py` | 5 | 5 | 215 |
| `src/conductor/test_ref_aware_governance.py` | 8 | 8 | 221 |
| `src/conductor/test_snapshot_worktree.py` | 7 | 7 | 241 |
