Pinned native source SLOC measurement
=====================================

Source commit: f8a1af1a4194eaec77e7dfcc0e7a997d47c69e95
Tree object: cdfe97770998707ddbc916202886777bbe8b5ee2
Git archive stream SHA-256: 88e6ac05a327e1a1cdd9f3c245712cc9ac01036caddaba5a69f0e0bbf2b7a563

This measures tracked Python, Rust, and shell source at the pinned commit,
using the unchanged path classification, Tokei 15.0.0, and syn-based
original-minus-masked inline Rust test treatment. It excludes current dirty
work. These percentages describe source composition, not runtime coverage,
behavioral coverage, or performance.

Production: Python 51,610 code lines; Rust 52,917; shell 194; native 50.5314%.
Tests: Python 25,993 code lines; Rust 73,774; Rust 73.9463%.
All tracked source including examples: Python 77,603; Rust 126,790; shell 194;
native 61.9736%.
Manifests: 375 production paths, 323 test paths, 700 counted source paths.
Two Rust example files with 99 code lines belong only to the all-source view.

The splitter found 100 test-only ranges in 85 production Rust files. Tokei
counts 43,180 Rust code lines in those original files and 30,121 after
masking, a 13,059-line test delta. Production Rust is 65,976 raw minus
13,059 inline-test lines = 52,917. Separate Rust test paths have 60,715
lines; adding the inline delta yields 73,774 Rust test lines.

Run the included measure-pinned.sh with the exact commit. It writes its
intermediates under /tmp/forge-native-metrics/f8a1af1-archive-evidence.
The included verify-f8a1af1.py independently classifies git ls-tree paths,
fetches every counted source with git cat-file --batch, checks SHA-256 and
archive bytes, re-runs the syn splitter on a separate archive extraction,
compares all 100 ranges and 85 masked/extracted copies, and re-runs Tokei
for every scope and per-file report. Its result is in
independent-verification.txt. Tokei's report array order varies, so reports
are compared by path and stats.

The archive includes NUL-delimited path manifests, all source hashes, exact
archive hash, raw Tokei JSON, AST ranges and counts, splitter source and
lockfile, both scripts, and executable/tool hashes. The source snapshot and
inline source copies are intentionally excluded; retrieve source by commit.

For independent reproduction, first run measure-pinned.sh to populate the
first evidence directory, then create a second extraction:

    mkdir -p /tmp/forge-native-metrics/f8a1af1-independent/source
    git archive f8a1af1a4194eaec77e7dfcc0e7a997d47c69e95 | tar -x -C /tmp/forge-native-metrics/f8a1af1-independent/source
    python verify-f8a1af1.py

The script uses the pinned tool paths recorded in tool-versions.txt and fails
on any manifest, blob, Tokei, splitter, or arithmetic mismatch.
