Pinned native source SLOC measurement
====================================

Source commit: 67976735870c79a94b8968255ce8e82a200e16b3
Measurement: tracked Python, Rust, and shell source from `git archive`.
These are source composition metrics, not runtime coverage, behavioral
coverage, or performance claims.

Counts
------

Production: Python 51,296; Rust 51,599; shell 194; native share 50.0529%.
Tests: Python 38,673; Rust 44,552; Rust share 53.5320%.
All tracked source including examples: Python 89,969; Rust 96,250; shell 194;
native share 51.6327%.
Manifests: 371 production files, 292 test files, 665 source files total.
The all-source manifest additionally contains two Rust example files; examples
are excluded from production and test scopes.

The splitter identified 100 test-only Rust item ranges in 85 production Rust
files. The original-minus-masked inline-test delta is 13,059 code lines:
43,010 original inline-file Rust lines minus 29,951 masked production lines.
Production Rust is 64,658 raw lines minus 13,059 inline-test lines = 51,599.
Rust tests are 31,493 separate Rust lines plus the same 13,059 inline-test
lines = 44,552.

Reproduction
------------

Run the included `measure-pinned.sh` with the exact source commit:

    ./measure-pinned.sh 67976735870c79a94b8968255ce8e82a200e16b3

The script writes its working snapshot and intermediates under
`/tmp/forge-native-metrics/6797673-archive-evidence`. It requires Tokei 15.0.0
and `forge-native-metric-split`. It derives tracked paths from `git ls-tree`,
extracts a `git archive`, measures raw Tokei JSON, and subtracts inline test
lines using original-minus-masked Rust files. The included Cargo manifest,
lockfile, and splitter source record the AST tool and dependency resolution.
The archive stream SHA-256 is in `archive-stream.sha256`. All 665 source file
SHA-256 values were independently checked against `git show <commit>:<path>`.

Evidence contents
-----------------

The package contains raw Tokei JSON for production, tests, all source, original
inline Rust files, and masked production Rust; NUL-delimited path manifests;
source hashes; AST ranges; count summaries; tool versions and executable
hashes; the splitter source and lockfile; the full reproduction script; and
this README. Extracted source snapshots and inline source-copy directories are
intentionally excluded. Retrieve the pinned source from Git using the recorded
commit ID.
