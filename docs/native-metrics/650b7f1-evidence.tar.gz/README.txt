Forge native source-composition measurement, commit 650b7f1205b8200b1494590ba2cde3c45e5dbf4c.

Measured with Tokei 15.0.0 and the archived syn splitter against a plain Git
archive, using the classification rules in docs/native-migration.md. No working
checkout source was counted. `measure-pinned.sh` produced the first archive;
`verify-650b7f1.sh` independently extracted the same Git tree, matched 749
counted file contents against Git blob SHA-256 values, reclassified paths,
reran Tokei and syn on the second extraction, and compared the per-file reports
and all 87 inline source copies. `verify-650b7f1-python-inventory.py` compared
surviving test/fixture Git blob IDs with the previous verified commit and
statically parsed the Python tests without importing or executing them.

Production: 51,633 Python + 53,724 Rust + 204 shell code lines; native 50.8938%.
Tests: 13,321 Python + 101,017 Rust code lines; Rust 88.3495%.
All tracked source including examples: 64,954 Python + 154,840 Rust + 204
shell code lines; native 70.3825%. The two example files contribute 99 Rust
code lines only to the all-source view. Inline Rust test attribution is 13,104
code lines: 43,893 original minus 30,789 masked across 87 files / 102 ranges.

Ten Python executable suites (122 named, 135 statically expanded cases) were
retired. The ten corresponding Rust contract targets contain 135 `#[test]`
functions; see `rust-contract-case-map.tsv`. The remaining 26 executable
Python suites contain 534 named and 595 statically expanded cases. The 34
Python fixture inputs and shared conftest are separate from executable suites.

`scoped-validation/` contains pre-commit development logs: 64 migrated
contracts, 41 guardrail contracts, 30 budget/value/provenance contracts,
11 contract-runner tests, 28 discovery tests, 5 local-check unit tests,
3 local-check integration tests, and 8 A2A SDK adapter tests. All displayed
Rust test summaries pass; the local-check Clippy log finishes successfully.
These scoped logs are auxiliary, not a source-pinned full local-check receipt.
The full `make local-check` and `make local-verify` gate was pending when this
measurement evidence was assembled.

`evidence-file-sha256.txt` lists every other packaged file. The archive's
SHA-256 is recorded separately in docs/native-migration.md. To reproduce,
extract this bundle into the standard /tmp/forge-native-metrics layout, use the
listed tool versions and locked splitter source, and run the two verification
scripts with the pinned Forge commit available in the checkout.
