#!/usr/bin/env python3
"""Verify pinned Python test retirement by Git blobs and static AST; never import tests."""
from __future__ import annotations

import ast
import csv
import io
import subprocess
from pathlib import Path

REPO = Path('/home/tim/Projects/llm-forge')
OLD = '98327f462928f6d90142977c93c532d53f6c2f02'
NEW = '650b7f1205b8200b1494590ba2cde3c45e5dbf4c'
OUT = Path('/tmp/forge-native-metrics/650b7f1-archive-evidence')
PRIOR = Path('/tmp/forge-native-metrics/650b7f1-prior-python-tests.tsv')


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def counts(path: Path) -> tuple[int, int]:
    tree = ast.parse(path.read_text(), filename=str(path))
    names = {
        node.targets[0].id: node.value
        for node in tree.body
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
    }
    tests = [
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name.startswith('test_')
    ]
    expanded = 0
    for test in tests:
        variants = 1
        for decorator in test.decorator_list:
            if not (
                isinstance(decorator, ast.Call)
                and isinstance(decorator.func, ast.Attribute)
                and decorator.func.attr == 'parametrize'
            ):
                continue
            values = decorator.args[1]
            if isinstance(values, (ast.List, ast.Tuple, ast.Set)):
                length = len(values.elts)
            elif isinstance(values, ast.Name) and isinstance(
                names.get(values.id), (ast.List, ast.Tuple, ast.Set)
            ):
                length = len(names[values.id].elts)
            elif (
                isinstance(values, ast.Call)
                and isinstance(values.func, ast.Name)
                and values.func.id == 'sorted'
                and isinstance(values.args[0], ast.Call)
                and isinstance(values.args[0].func, ast.Attribute)
                and values.args[0].func.attr == 'values'
                and isinstance(values.args[0].func.value, ast.Name)
            ):
                mapping = names[values.args[0].func.value.id]
                assert isinstance(mapping, ast.Dict)
                length = len(mapping.keys)
            else:
                raise AssertionError(f'unhandled parametrization {path}:{test.lineno}')
            variants *= length
        expanded += variants
    return len(tests), expanded


with PRIOR.open(newline='') as handle:
    rows = list(csv.DictReader(handle, delimiter='\t'))
assert len(rows) == 71
manifest = {
    path.decode()
    for path in (OUT / 'test-source.paths0').read_bytes().split(b'\0')
    if path.endswith(b'.py')
}
retired = [row for row in rows if not (OUT / 'source' / row['path']).is_file()]
surviving = [row for row in rows if (OUT / 'source' / row['path']).is_file()]
assert len(retired) == 10 and len(surviving) == 61
assert manifest == {row['path'] for row in surviving}
assert all(row['category'] == 'executable_test' for row in retired)
for row in surviving:
    path = row['path']
    assert git('rev-parse', f'{OLD}:{path}') == git('rev-parse', f'{NEW}:{path}')
    source = OUT / 'source' / path
    assert len(source.read_text().splitlines()) == int(row['physical_lines'])
    if row['category'] == 'executable_test':
        assert counts(source) == (
            int(row['named']), int(row['static_expanded_cases'])
        ), path
for row in retired:
    source = REPO / row['path']
    content = subprocess.check_output(['git', 'show', f'{OLD}:{row["path"]}'], cwd=REPO)
    scratch = OUT / 'retired-source' / row['path']
    scratch.parent.mkdir(parents=True, exist_ok=True)
    scratch.write_bytes(content)
    assert counts(scratch) == (int(row['named']), int(row['static_expanded_cases']))

changes = git('diff', '--name-status', OLD, NEW, '--', '*.py').splitlines()
expected = ['M\tsrc/conductor/agent_a2a.py'] + [f'D\t{r["path"]}' for r in retired]
assert sorted(changes) == sorted(expected), (changes, expected)
assert sum(int(r['named']) for r in retired) == 122
assert sum(int(r['static_expanded_cases']) for r in retired) == 135
assert sum(int(r['physical_lines']) for r in retired) == 2844
category_counts = {
    category: sum(row['category'] == category for row in surviving)
    for category in ('executable_test', 'fixture_input', 'shared_conftest')
}
assert category_counts == {
    'executable_test': 26, 'fixture_input': 34, 'shared_conftest': 1
}, category_counts
assert sum(int(r['named']) for r in surviving if r['category'] == 'executable_test') == 534
assert sum(int(r['static_expanded_cases']) for r in surviving if r['category'] == 'executable_test') == 595
fieldnames = list(rows[0])
for filename, group in [('remaining-python-tests.tsv', surviving), ('retired-python-tests.tsv', retired)]:
    with (OUT / filename).open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter='\t')
        writer.writeheader()
        writer.writerows(group)
(OUT / 'python-inventory-verification.txt').write_text(
    f'commit={NEW}\n'
    'prior_commit=' + OLD + '\n'
    'retired_executable_suites=10 named=122 static_expanded=135 physical_lines=2844\n'
    'remaining_executable_suites=26 named=534 static_expanded=595\n'
    'remaining_fixture_inputs=34 shared_conftest=1\n'
    'surviving_python_test_fixture_blob_oids=61/61 unchanged\n'
    'surviving_python_test_manifest_paths=61/61 exact\n'
    'surviving_executable_ast_counts=26/26 exact\n'
    'retired_executable_ast_counts=10/10 exact\n'
    'python_source_diff=agent_a2a_modified_plus_10_test_deletions_exact\n'
)
print((OUT / 'python-inventory-verification.txt').read_text(), end='')
