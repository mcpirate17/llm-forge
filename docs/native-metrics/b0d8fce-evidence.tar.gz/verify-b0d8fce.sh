#!/usr/bin/env bash
set -euo pipefail
repo=/home/tim/Projects/llm-forge
rev=b0d8fced801aa6d85acf6b8e38de9c448a94b736
first=/tmp/forge-native-metrics/b0d8fce-archive-evidence
second=/tmp/forge-native-metrics/b0d8fce-independent
tokei=/tmp/forge-native-metrics/bin/tokei
split=/tmp/forge-native-metrics/syn-split/target/release/forge-native-metric-split
mkdir -p "$second/source"
cd "$repo"
git archive "$rev" > "$second/archive.tar"
sha256sum "$second/archive.tar" > "$first/archive-stream.sha256"
tar -xf "$second/archive.tar" -C "$second/source"
rm "$second/archive.tar"
diff -qr "$first/source" "$second/source" > "$second/source-tree-diff.txt"
: > "$second/tracked.paths0"
: > "$second/all-source.paths0"
: > "$second/production-source.paths0"
: > "$second/test-source.paths0"
: > "$second/source-content-sha256.txt"
: > "$second/git-blob-content-sha256.txt"
count=0
examples=0
while IFS= read -r -d '' row; do
  p=${row#*$'\t'}
  meta=${row%%$'\t'*}
  oid=${meta##* }
  printf '%s\0' "$p" >> "$second/tracked.paths0"
  case "$p" in *.py|*.rs|*.sh) ;; *) continue ;; esac
  case "$p" in docs/*|research/*|target/*|*/target/*|build/*|*/build/*|dist/*|*/dist/*|.venv/*|*/.venv/*) continue ;; esac
  printf '%s\0' "$p" >> "$second/all-source.paths0"
  is_test=0
  case "/$p/" in */tests/*|*/testdata/*) is_test=1 ;; esac
  case "$p" in *_tests.rs|*/tests.rs|conftest.py|*/conftest.py|test_*.py|*/test_*.py|*_test.py) is_test=1 ;; esac
  if ((is_test)); then
    printf '%s\0' "$p" >> "$second/test-source.paths0"
  elif [[ "$p" == native/forge/examples/* ]]; then
    examples=$((examples+1))
  else
    printf '%s\0' "$p" >> "$second/production-source.paths0"
  fi
  git cat-file blob "$oid" | sha256sum | sed "s|  -$|  $p|" >> "$second/git-blob-content-sha256.txt"
  sha256sum "$second/source/$p" | sed "s#  $second/source/#  #" >> "$second/source-content-sha256.txt"
  count=$((count+1))
done < <(git ls-tree -rz "$rev")
for f in tracked.paths0 all-source.paths0 production-source.paths0 test-source.paths0 source-content-sha256.txt; do
  cmp "$first/$f" "$second/$f"
done
cmp "$first/source-content-sha256.txt" "$second/git-blob-content-sha256.txt"
cp "$second/production-source.paths0" "$second/production.paths0"
"$split" "$second/source" "$second/production.paths0" "$second/inline-prod" "$second/inline-test" "$second/inline-ranges.tsv" > "$second/split-summary.txt"
cmp "$first/inline-ranges.tsv" "$second/inline-ranges.tsv"
cmp "$first/split-summary.txt" "$second/split-summary.txt"
diff -qr "$first/inline-prod" "$second/inline-prod" > "$second/inline-prod-diff.txt"
diff -qr "$first/inline-test" "$second/inline-test" > "$second/inline-test-diff.txt"
for pair in 'production-source.paths0 production-raw-tokei.json' 'test-source.paths0 test-raw-tokei.json' 'all-source.paths0 all-raw-tokei.json' 'inline-rust-paths.paths0 inline-original-tokei.json'; do
  read -r manifest report <<< "$pair"
  (cd "$second/source"; xargs -0 "$tokei" --no-ignore --output json < "$first/$manifest") > "$second/$report"
  jq -S 'walk(if type=="array" and all(.[]; type=="object" and has("name")) then sort_by(.name) else . end)' "$first/$report" > "$second/first-normalized.json"
  jq -S 'walk(if type=="array" and all(.[]; type=="object" and has("name")) then sort_by(.name) else . end)' "$second/$report" > "$second/second-normalized.json"
  cmp "$second/first-normalized.json" "$second/second-normalized.json"
done
find "$second/inline-prod" -type f -name '*.rs' -print0 | xargs -0 "$tokei" --no-ignore --output json > "$second/inline-masked-prod-tokei.json"
jq -S 'walk(if type=="array" and all(.[]; type=="object" and has("name")) then sort_by(.name) else . end)' "$first/inline-masked-prod-tokei.json" > "$second/first-normalized.json"
jq -S --arg prefix "$second/inline-prod/" --arg replace "$first/inline-prod/" 'walk(if type=="object" and has("name") then .name |= sub("^"+$prefix;$replace) elif type=="array" and all(.[]; type=="object" and has("name")) then sort_by(.name) else . end)' "$second/inline-masked-prod-tokei.json" > "$second/second-normalized.json"
cmp "$second/first-normalized.json" "$second/second-normalized.json"
orig=$(jq -r '.Rust.code' "$first/inline-original-tokei.json")
masked=$(jq -r '.Rust.code' "$first/inline-masked-prod-tokei.json")
inline=$((orig-masked))
prod_rust=$(jq -r '.Rust.code' "$first/production-raw-tokei.json")
test_rust=$(jq -r '.Rust.code' "$first/test-raw-tokei.json")
all_rust=$(jq -r '.Rust.code' "$first/all-raw-tokei.json")
[[ $((prod_rust-inline)) == $(sed -n 's/^production_rust=//p' "$first/metrics.txt") ]]
[[ $((test_rust+inline)) == $(sed -n 's/^test_rust=//p' "$first/metrics.txt") ]]
[[ $((all_rust-prod_rust-test_rust)) == 99 ]]
[[ "$count" == 745 && "$examples" == 2 && "$orig" == 43180 && "$masked" == 30121 && "$inline" == 13059 ]]
printf 'commit=%s\narchive_sha256=%s\nindependent_git_blobs=%s/%s\nsource_sha256_checks=%s/%s\nindependent_archive_tree=exact\nclassified_manifests=exact\nindependent_tokei_per_file_reports=exact\nindependent_ast_split_ranges=exact\nindependent_inline_source_copies=85/85\nindependent_raw_count_arithmetic=exact\n' "$rev" "$(cut -d ' ' -f 1 "$first/archive-stream.sha256")" "$count" "$count" "$count" "$count" > "$first/independent-verification.txt"
