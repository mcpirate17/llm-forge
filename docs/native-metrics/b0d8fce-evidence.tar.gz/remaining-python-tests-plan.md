# Remaining executable Python tests at b0d8fce

Pinned commit: `b0d8fced801aa6d85acf6b8e38de9c448a94b736`. The source inventory is `/tmp/forge-remaining-python-tests.tsv`, copied from the deterministic evidence bundle `docs/native-metrics/b0d8fce-evidence.tar.gz`. It contains **42 executable suites, 749 named test functions, 829 statically expanded parameter cases, and 19,976 physical lines**. Another 34 Python fixture inputs and one shared conftest are separate categories in the TSV. These counts come from the archived source, not pytest collection or behavioral coverage.

Compared with verified `af62ae0`, four executable suites were retired: `test_bytecode_isolation.py`, `test_checkout_sync.py`, `test_policy_engine_crash.py`, and `test_workspace_eval.py` (27 named and 27 expanded cases, 631 physical lines). Two Python fixture inputs under `src/conductor/testdata/workspace_hooks/` were added. All 75 surviving Python test blobs are byte-identical to the prior pin; the two fixture blobs match the new pin. The fixture inputs are test data, not migrated algorithms or executable suites. Dirty checkout files are excluded.

## Executable suites

| Path | Named tests | Static cases | Physical lines |
| --- | ---: | ---: | ---: |
| `src/conductor/test_candidate_review.py` | 56 | 56 | 3110 |
| `src/conductor/test_candidate_review_call_and_evidence.py` | 19 | 39 | 560 |
| `src/conductor/test_candidate_review_claims_view.py` | 5 | 5 | 146 |
| `src/conductor/test_candidate_review_hardening.py` | 12 | 12 | 430 |
| `src/conductor/test_candidate_review_scan_coverage.py` | 6 | 6 | 190 |
| `src/conductor/test_ci_history_fetch.py` | 11 | 11 | 457 |
| `src/conductor/test_cpu_embed.py` | 53 | 54 | 797 |
| `src/conductor/test_crg_seed_worktree.py` | 7 | 7 | 271 |
| `src/conductor/test_current_work_guard.py` | 21 | 21 | 311 |
| `src/conductor/test_doctor.py` | 25 | 34 | 368 |
| `src/conductor/test_equivalence_probe.py` | 34 | 34 | 991 |
| `src/conductor/test_external_invariants.py` | 13 | 13 | 290 |
| `src/conductor/test_gate.py` | 33 | 33 | 520 |
| `src/conductor/test_gate_policy_provenance.py` | 5 | 5 | 215 |
| `src/conductor/test_gate_rollout.py` | 23 | 23 | 433 |
| `src/conductor/test_governance_identity.py` | 14 | 19 | 180 |
| `src/conductor/test_guardrail_audit.py` | 22 | 27 | 474 |
| `src/conductor/test_guardrail_duplicates.py` | 9 | 14 | 153 |
| `src/conductor/test_installed_layout.py` | 1 | 1 | 123 |
| `src/conductor/test_mutation_attribution.py` | 20 | 26 | 673 |
| `src/conductor/test_mutation_campaign_generate.py` | 25 | 26 | 947 |
| `src/conductor/test_mutation_patch_audit.py` | 27 | 27 | 1407 |
| `src/conductor/test_mutation_retention.py` | 32 | 32 | 768 |
| `src/conductor/test_ownership_claim_expiry.py` | 19 | 19 | 279 |
| `src/conductor/test_package_resources.py` | 16 | 23 | 506 |
| `src/conductor/test_probe_budget.py` | 11 | 11 | 439 |
| `src/conductor/test_radon_complexity.py` | 13 | 13 | 178 |
| `src/conductor/test_receipt_verify.py` | 7 | 7 | 207 |
| `src/conductor/test_ref_aware_governance.py` | 8 | 8 | 221 |
| `src/conductor/test_run_duplicate_audit.py` | 25 | 31 | 819 |
| `src/conductor/test_runner_lineage.py` | 14 | 17 | 187 |
| `src/conductor/test_slop_gate.py` | 19 | 19 | 430 |
| `src/conductor/test_slop_ledger.py` | 16 | 16 | 330 |
| `src/conductor/test_snapshot_worktree.py` | 7 | 7 | 241 |
| `src/conductor/test_tooling_boundary.py` | 31 | 40 | 486 |
| `src/conductor/test_value_gate_scope.py` | 14 | 14 | 263 |
| `src/conductor/test_vulture_audit.py` | 13 | 14 | 309 |
| `src/conductor/test_workspace_hygiene.py` | 17 | 17 | 345 |
| `src/conductor/test_worktree_lease.py` | 9 | 11 | 117 |
| `src/conductor/test_worktree_reap.py` | 32 | 32 | 497 |
| `src/conductor/test_worktree_runtime.py` | 3 | 3 | 152 |
| `src/tooling/hooks/claude/test_workspace_exposure_parity_corpus.py` | 2 | 2 | 156 |

## Smallest suites by physical lines

This size view can guide a bounded next-cohort audit; it does not establish replacement coverage, runtime safety, or ownership.

| Path | Named tests | Static cases | Physical lines |
| --- | ---: | ---: | ---: |
| `src/conductor/test_worktree_lease.py` | 9 | 11 | 117 |
| `src/conductor/test_installed_layout.py` | 1 | 1 | 123 |
| `src/conductor/test_candidate_review_claims_view.py` | 5 | 5 | 146 |
| `src/conductor/test_worktree_runtime.py` | 3 | 3 | 152 |
| `src/conductor/test_guardrail_duplicates.py` | 9 | 14 | 153 |
| `src/tooling/hooks/claude/test_workspace_exposure_parity_corpus.py` | 2 | 2 | 156 |
| `src/conductor/test_radon_complexity.py` | 13 | 13 | 178 |
| `src/conductor/test_governance_identity.py` | 14 | 19 | 180 |
| `src/conductor/test_runner_lineage.py` | 14 | 17 | 187 |
| `src/conductor/test_candidate_review_scan_coverage.py` | 6 | 6 | 190 |
| `src/conductor/test_receipt_verify.py` | 7 | 7 | 207 |
| `src/conductor/test_gate_policy_provenance.py` | 5 | 5 | 215 |
