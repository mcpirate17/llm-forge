#!/usr/bin/env bash
set -euo pipefail
repo=/home/tim/Projects/llm-forge
old=af62ae016a705f57e2f0bc7de2b89ef323af14a9
new=b0d8fced801aa6d85acf6b8e38de9c448a94b736
out=/tmp/forge-native-metrics/b0d8fce-archive-evidence
bundle=$(realpath -- "$(dirname -- "${BASH_SOURCE[0]}")")
prior="$bundle/prior-af62ae0-python-tests.tsv"
remaining="$bundle/remaining-python-tests.tsv"
retired="$bundle/retired-python-tests.tsv"
expected=/tmp/forge-native-metrics/b0d8fce-expected-python-diff.txt
cat > "$expected" <<'PATHS'
D	src/conductor/test_bytecode_isolation.py
D	src/conductor/test_checkout_sync.py
D	src/conductor/test_policy_engine_crash.py
D	src/conductor/test_workspace_eval.py
A	src/conductor/testdata/workspace_hooks/crg_gate.py
A	src/conductor/testdata/workspace_hooks/obsidian_sync.py
PATHS
cd "$repo"
git diff --name-status "$old" "$new" -- '*.py' > /tmp/forge-native-metrics/b0d8fce-python-diff.txt
cmp "$expected" /tmp/forge-native-metrics/b0d8fce-python-diff.txt
awk -F '\t' 'NR==1 || ($1 != "shared_conftest" && $6 !~ /^src\/conductor\/test_(bytecode_isolation|checkout_sync|policy_engine_crash|workspace_eval)\.py$/)' "$prior" > /tmp/forge-native-metrics/b0d8fce-rederived-python-tests.tsv
printf 'fixture_input\t0\t0\t0\t9\tsrc/conductor/testdata/workspace_hooks/crg_gate.py\t\r\nfixture_input\t0\t0\t0\t6\tsrc/conductor/testdata/workspace_hooks/obsidian_sync.py\t\r\n' >> /tmp/forge-native-metrics/b0d8fce-rederived-python-tests.tsv
awk -F '\t' '$1 == "shared_conftest"' "$prior" >> /tmp/forge-native-metrics/b0d8fce-rederived-python-tests.tsv
cmp "$remaining" /tmp/forge-native-metrics/b0d8fce-rederived-python-tests.tsv
awk -F '\t' 'NR==1 || $6 ~ /^src\/conductor\/test_(bytecode_isolation|checkout_sync|policy_engine_crash|workspace_eval)\.py$/' "$prior" > /tmp/forge-native-metrics/b0d8fce-rederived-retired-python-tests.tsv
cmp "$retired" /tmp/forge-native-metrics/b0d8fce-rederived-retired-python-tests.tsv
tr '\0' '\n' < "$out/test-source.paths0" | rg '\.py$' | sort > /tmp/forge-native-metrics/b0d8fce-manifest-python.txt
tail -n +2 "$remaining" | cut -f6 | sort > /tmp/forge-native-metrics/b0d8fce-inventory-python.txt
cmp /tmp/forge-native-metrics/b0d8fce-manifest-python.txt /tmp/forge-native-metrics/b0d8fce-inventory-python.txt
old_count=0
new_count=0
while IFS=$'\t' read -r category named expanded dynamic physical path parse_error; do
  [[ "$category" == category ]] && continue
  if [[ "$path" == src/conductor/testdata/workspace_hooks/crg_gate.py || "$path" == src/conductor/testdata/workspace_hooks/obsidian_sync.py ]]; then
    [[ "$category" == fixture_input && "$named" == 0 && "$expanded" == 0 ]]
    [[ "$physical" == "$(wc -l < "$out/source/$path")" ]]
    [[ "$(git rev-parse "$new:$path")" == "$(git hash-object "$out/source/$path")" ]]
    new_count=$((new_count+1))
  else
    [[ "$(git rev-parse "$old:$path")" == "$(git rev-parse "$new:$path")" ]]
    old_count=$((old_count+1))
  fi
done < "$remaining"
[[ "$old_count" == 75 && "$new_count" == 2 ]]
[[ "$(awk -F '\t' 'NR>1 {n+=$2;e+=$3;c++} END{print c,n,e}' "$retired")" == '4 27 27' ]]
{
  printf 'commit=%s\n' "$new"
  printf 'python_test_manifest_paths=77/77\n'
  printf 'surviving_python_blob_oids_vs_af62ae0=75/75\n'
  printf 'new_python_fixture_blob_oids=2/2\n'
  printf 'retired_executable_suites=4 named=27 static_expanded=27 physical_lines=631\n'
  awk -F '\t' 'NR>1 {c[$1]++; n[$1]+=$2; e[$1]+=$3; p[$1]+=$5} END {for (k in c) printf "%s: files=%d named=%d static_expanded=%d physical_lines=%d\n", k,c[k],n[k],e[k],p[k]}' "$remaining" | sort
} > "$out/python-inventory-verification.txt"
