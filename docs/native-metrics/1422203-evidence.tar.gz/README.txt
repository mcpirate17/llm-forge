Pinned native source SLOC measurement
====================================

Source commit: 1422203b47bd72798af6b6c0d6adff47df69c5d1
Measurement: tracked Python, Rust, and shell source from `git archive`.
These are source composition metrics, not runtime coverage, behavioral
coverage, or performance claims.

Counts
------

Production: Python 51,296; Rust 51,599; shell 194; native share 50.0529%.
Tests: Python 36,780; Rust 48,361; Rust share 56.8011%.
All tracked source including examples: Python 88,076; Rust 100,059; shell
194; native share 53.1299%.
Manifests: 371 production files, 288 test files, 661 source files total.
The all-source manifest also contains two Rust example files, excluded from
production and test scopes.

The splitter identified 100 test-only Rust item ranges in 85 production Rust
files. The inline-test attribution is the original-minus-masked delta:
43,010 original inline-file Rust lines minus 29,951 masked production lines
= 13,059 lines. Production Rust is 64,658 raw lines minus 13,059 = 51,599.
Rust tests are 35,302 separate Rust lines plus the same 13,059 inline lines
= 48,361.

Reproduction
------------

Run the included `measure-pinned.sh` with the exact source commit:

    ./measure-pinned.sh 1422203b47bd72798af6b6c0d6adff47df69c5d1

The script writes its working snapshot and intermediates under
`/tmp/forge-native-metrics/1422203-archive-evidence`. It requires Tokei 15.0.0
and `forge-native-metric-split`. It derives tracked paths from `git ls-tree`,
extracts a Git archive, measures raw Tokei JSON, and attributes inline tests
using original-minus-masked Rust files. The Cargo manifest, lockfile, and
splitter source record the AST tool and dependency resolution. The archive
stream SHA-256 is in `archive-stream.sha256`. All 661 source file SHA-256
values were independently checked against the corresponding committed Git
blob.

Evidence contents
-----------------

The package contains raw Tokei JSON for production, tests, all source, original
inline Rust files, and masked production Rust; NUL-delimited path manifests;
source hashes; AST ranges; count summaries; tool versions and executable
hashes; the splitter source and lockfile; the full reproduction script; and
this README. Extracted source snapshots and inline source-copy directories are
intentionally excluded. Retrieve pinned source from Git using the commit ID.
