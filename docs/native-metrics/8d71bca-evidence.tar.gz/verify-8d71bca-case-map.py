#!/usr/bin/env python3
"""Verify the 134 retired Python cases map exactly to nine pinned Rust targets."""
from __future__ import annotations

import ast
import csv
import hashlib
import re
import subprocess
from collections import Counter
from pathlib import Path

REPO = Path("/home/tim/Projects/llm-forge")
OLD = "f223e64e4711e4dc3c6487ea0d1421b4a75db9b8"
NEW = "8d71bca853c0e3f83d0747ea9bb317338356df48"
OUT = Path("/tmp/forge-native-metrics/8d71bca-archive-evidence")
SOURCE = OUT / "source"
COHORTS = (
    ("native-worktree-contract-migration.md", (
        ("worktree_runtime", 3), ("worktree_lease", 11),
        ("snapshot_worktree", 7), ("crg_seed_worktree", 7),
    )),
    ("native-gate-contract-migration.md", (("gate", 33), ("gate_rollout", 23))),
    ("native-audit-contract-migration.md", (
        ("ci_history_fetch", 11), ("ref_aware_governance", 8),
        ("run_duplicate_audit", 31),
    )),
)


def git_bytes(commit: str, path: str) -> bytes:
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=REPO)


def variants_by_test(source: bytes, path: str) -> dict[str, int]:
    tree = ast.parse(source, filename=path)
    names = {
        node.targets[0].id: node.value
        for node in tree.body
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
    }
    results = {}
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or not node.name.startswith("test_"):
            continue
        variants = 1
        for decorator in node.decorator_list:
            if not (
                isinstance(decorator, ast.Call)
                and isinstance(decorator.func, ast.Attribute)
                and decorator.func.attr == "parametrize"
            ):
                continue
            value = decorator.args[1]
            if isinstance(value, (ast.List, ast.Tuple, ast.Set)):
                length = len(value.elts)
            elif isinstance(value, ast.Name) and isinstance(names.get(value.id), (ast.List, ast.Tuple, ast.Set)):
                length = len(names[value.id].elts)
            elif (
                isinstance(value, ast.Call)
                and isinstance(value.func, ast.Name)
                and value.func.id == "sorted"
                and isinstance(value.args[0], ast.Call)
                and isinstance(value.args[0].func, ast.Attribute)
                and value.args[0].func.attr == "values"
                and isinstance(value.args[0].func.value, ast.Name)
            ):
                mapping = names[value.args[0].func.value.id]
                assert isinstance(mapping, ast.Dict)
                length = len(mapping.keys)
            else:
                raise AssertionError(f"unhandled parametrization {path}:{node.lineno}")
            variants *= length
        results[node.name] = variants
    return results


all_rows: list[dict[str, str]] = []
for doc, targets in COHORTS:
    contents = (SOURCE / "docs" / doc).read_text()
    rows = re.findall(r'^\| `(test_\w+(?:\[[^]]+\])?)` \| `(\w+)` \|$', contents, re.M)
    assert len(rows) == sum(count for _, count in targets), doc
    start = 0
    for stem, count in targets:
        mapping = rows[start:start + count]
        start += count
        original = f"src/conductor/test_{stem}.py"
        rust = f"native/conductor-native/tests/python_contracts_{stem}.rs"
        expected = variants_by_test(git_bytes(OLD, original), original)
        original_bases = Counter(case.split("[")[0] for case, _ in mapping)
        assert original_bases == expected, stem
        rust_source = (SOURCE / rust).read_text()
        rust_names = set(re.findall(r'^#\[test\]\nfn (\w+)\(', rust_source, re.M))
        mapped_names = {case for _, case in mapping}
        assert len(rust_names) == count and rust_names == mapped_names, stem
        for original_case, rust_case in mapping:
            all_rows.append({
                "original_file": original,
                "original_case": original_case,
                "rust_target": f"python_contracts_{stem}",
                "rust_case": rust_case,
            })
assert len(all_rows) == 134
with (OUT / "rust-contract-case-map.tsv").open("w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(all_rows[0]), delimiter="\t")
    writer.writeheader()
    writer.writerows(all_rows)

matched = (Path("/tmp/forge-native67-perf") / "matched-source-sha256.txt").read_text().splitlines()
originals = 0
committed = 0
for line in matched:
    digest, path = line.split("  ", 1)
    commit = OLD if path.startswith("src/conductor/test_") else NEW
    actual = hashlib.sha256(git_bytes(commit, path)).hexdigest()
    assert actual == digest, path
    if commit == OLD:
        originals += 1
    else:
        committed += 1
assert originals == 9 and committed == 14
(OUT / "matched-benchmark-source-verification.txt").write_text(
    f"original_parent={OLD}\nnew_source={NEW}\n"
    "original_python_sha256=9/9 exact\n"
    "native_targets_and_helpers_sha256=14/14 exact\n"
    "source_file_hashes=23/23 exact\n"
)
(OUT / "case-map-verification.txt").write_text(
    f"commit={NEW}\noriginal_parent={OLD}\n"
    "python_expanded_cases=134/134 exact\n"
    "native_test_functions=134/134 exact\n"
    "case_map_rows=134/134 exact\n"
    "mapped_original_names_and_param_counts=126/126 exact\n"
)
print((OUT / "case-map-verification.txt").read_text(), end="")
print((OUT / "matched-benchmark-source-verification.txt").read_text(), end="")
