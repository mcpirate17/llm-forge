#!/usr/bin/env bash
set -euo pipefail
cd /home/tim/Projects/llm-forge
export PATH="$PWD/.venv/bin:$PATH"
export PYO3_PYTHON="$PWD/.venv/bin/python"
export PYTHONPATH="$PWD/src:$PWD/.venv/lib/python3.12/site-packages"
export FORGE_BIN="$PWD/.venv/bin/forge"
export SQLITE3_LIB_DIR=/tmp/forge-sqlite-link
export CARGO_BUILD_JOBS=2 RUST_TEST_THREADS=1
export CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
unset PYO3_CONFIG_FILE PYO3_NO_PYTHON
perf_dir=/tmp/forge-native67-perf
stems=(worktree_runtime worktree_lease snapshot_worktree crg_seed_worktree gate gate_rollout ci_history_fetch ref_aware_governance run_duplicate_audit)
if [[ ${1:-} == python ]]; then
  inputs=()
  for stem in "${stems[@]}"; do inputs+=("src/conductor/test_$stem.py"); done
  exec .venv/bin/python -m pytest -q -p no:cacheprovider --timeout 120 "${inputs[@]}"
fi
if [[ ${1:-} == rust ]]; then
  while IFS= read -r binary; do "$binary" --test-threads=1; done < "$perf_dir/binaries.txt"
  exit
fi
mkdir -p "$perf_dir"
targets=()
for stem in "${stems[@]}"; do targets+=(--test "python_contracts_$stem"); done
cargo +1.98.0 test --offline --locked --manifest-path native/conductor-native/Cargo.toml \
  --features python-compat-tests --no-run --message-format=json "${targets[@]}" \
  > "$perf_dir/build.jsonl" 2> "$perf_dir/build.log"
jq -r 'select(.reason == "compiler-artifact" and .profile.test == true and .executable != null) | .executable' \
  "$perf_dir/build.jsonl" > "$perf_dir/binaries.txt"
test "$(wc -l < "$perf_dir/binaries.txt")" -eq 9
bash "$0" python > "$perf_dir/warm-python.log" 2>&1
bash "$0" rust > "$perf_dir/warm-rust.log" 2>&1
for round in 1 2 3; do
  arms=(python rust)
  if [[ $round == 2 ]]; then arms=(rust python); fi
  for arm in "${arms[@]}"; do
    /usr/bin/time -f 'wall_s=%e user_s=%U system_s=%S max_rss_kib=%M' \
      -o "$perf_dir/$round-$arm.time" bash "$0" "$arm" \
      > "$perf_dir/$round-$arm.log" 2>&1
  done
done
cat "$perf_dir"/*.time
