Pinned native migration measurement: 8d71bca853c0e3f83d0747ea9bb317338356df48

Run measure-pinned.sh COMMIT to reproduce the source count from a plain git
archive. It is byte identical to the script in 650b7f1-evidence.tar.gz.
The syn splitter source and lockfile are likewise unchanged. The unchanged
classification excludes generated paths, dependencies, docs, research, and
examples from the two milestone scopes. Python/Rust/Shell code SLOC comes
from Tokei 15.0.0. Rust test-only items embedded in production files are
identified with syn and attributed to the test numerator by subtracting the
masked full-file code count from the original full-file code count.

verify-8d71bca.sh independently extracts the same commit, recomputes each
counted-source SHA-256 from Git blob bytes, reconstructs and compares the
NUL-delimited path manifests, repeats Tokei and the Rust AST split, and checks
raw-count arithmetic. Its receipt is independent-verification.txt. The
source/ and inline source copies are deliberately omitted from this compact
archive; both scripts reproduce them under /tmp.

verify-8d71bca-python.py checks the exact nine removed Python paths against
the previous 650b7f1 inventory, AST counts all 134 expanded cases, proves the
52 surviving Python test/fixture blobs are unchanged, and writes the retired
and remaining inventories. verify-8d71bca-case-map.py checks the three
committed migration maps against the original test definitions from parent
f223e64e4711e4dc3c6487ea0d1421b4a75db9b8 and all 134 committed Rust
test function names. It also verifies 23 matched benchmark source digests:
nine Python originals from the parent and nine Rust targets plus five helpers
from the new commit. No Python originals were restored to the shared checkout.

The matched-performance directory contains forge-native67-benchmark.sh,
the nine-binary Cargo build record, warmups, three paired Python/Rust rounds
in AB/BA/AB order, source hashes, and interpreter/package context. Compilation
is excluded from timed rounds. Both arms passed 134 cases in each round.
Median outer-process wall times are 1.53 s Python and 2.35 s Rust; median
peak RSS is 54,788 KiB Python and 45,764 KiB Rust. This measures the two
test harnesses on this machine, not production throughput. Both arms use the
same unchanged production Python APIs and installed conductor-native 0.1.66;
the Rust harness crate source is the new 0.1.67 commit. Timestamps and runs
precede original-file retirement; the benchmark is reproducible from the
parent originals and committed native tests.

The collection logs show 134 original cases before retirement and 427 cases
currently collected. The pinned inventory has 17 executable Python suites
and 461 statically expanded cases; the 34-case test_equivalence_probe.py
module calls pytest.importorskip("torch") and is not collected in this Forge
environment. Thus 427 collected and 461 static are distinct measurements.
The suite remains to be exercised in an environment with torch. This archive
contains only the scoped validation known at assembly time; the root lane
runs the full gate after the metric documentation is committed.
