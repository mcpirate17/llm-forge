Pinned native source SLOC measurement
=====================================

Source commit: 98ce5ea915376f9d52aba173f0eb6e0458f940cf
Tree object: 952a11592efcd9ef1872c128dcfee07db2b5aaf6
Git archive stream SHA-256: a183d0d2991aae4273174d78dbbe081341d1ad4f502aa9c4f1b280057401e7e0

This measures tracked Python, Rust, and shell source at the pinned commit,
using the unchanged path classification, Tokei 15.0.0, and syn-based
original-minus-masked inline Rust test treatment. It excludes current dirty
work. These percentages describe source composition, not runtime coverage,
behavioral coverage, or performance.

Production: Python 51,610 code lines; Rust 52,945; shell 194; native 50.5446%.
Tests: Python 24,650 code lines; Rust 76,825; Rust 75.7083%.
All tracked source including examples: Python 76,260; Rust 129,869; shell 194;
native 62.9445%.
Manifests: 375 production paths, 328 test paths, 705 counted source paths.
Two Rust example files with 99 code lines belong only to the all-source view.

The splitter found 100 test-only ranges in 85 production Rust files. Tokei
counts 43,180 Rust code lines in those original files and 30,121 after
masking, a 13,059-line test delta. Production Rust is 66,004 raw minus
13,059 inline-test lines = 52,945. Separate Rust test paths have 63,766
lines; adding the inline delta yields 76,825 Rust test lines.

Run the included measure-pinned.sh with the exact commit. It writes its
intermediates under /tmp/forge-native-metrics/98ce5ea-archive-evidence.
The included verify-98ce5ea.py independently classifies git ls-tree paths,
fetches every counted source with git cat-file --batch, checks SHA-256 and
archive bytes, re-runs the syn splitter on a separate archive extraction,
compares all 100 ranges and 85 masked/extracted copies, and re-runs Tokei
for every scope and per-file report. Its result is in
independent-verification.txt. Tokei's report array order varies, so reports
are compared by path and stats.

The archive includes NUL-delimited path manifests, all source hashes, exact
archive hash, raw Tokei JSON, AST ranges and counts, splitter source and
lockfile, both scripts, and executable/tool hashes. The source snapshot and
inline source copies are intentionally excluded; retrieve source by commit.

For independent reproduction, first run measure-pinned.sh to populate the
first evidence directory, then create a second extraction:

    mkdir -p /tmp/forge-native-metrics/98ce5ea-independent/source
    git archive 98ce5ea915376f9d52aba173f0eb6e0458f940cf | tar -x -C /tmp/forge-native-metrics/98ce5ea-independent/source
    python verify-98ce5ea.py

The script uses the pinned tool paths recorded in tool-versions.txt and fails
on any manifest, blob, Tokei, splitter, or arithmetic mismatch.
