#!/usr/bin/env bash
set -euo pipefail
repo=/home/tim/Projects/llm-forge
out=/tmp/forge-native-metrics/b40b79a-archive-evidence
old=14e570e6c7d2798a1ef9586c0f4e04863bc28a0d
new=b40b79ad42c9188fba9f3cf4ac09e6f637fa0de9
cd "$repo"
awk -F '\t' 'NR==1 || $6 != "src/tooling/hooks/claude/test_hook_project_seam.py"' "$out/prior-14e570e-python-tests.tsv" > /tmp/forge-native-metrics/b40b79a-rederived-python-tests.tsv
cmp "$out/remaining-python-tests.tsv" /tmp/forge-native-metrics/b40b79a-rederived-python-tests.tsv
tr '\0' '\n' < "$out/test-source.paths0" | rg '\.py$' | sort > /tmp/forge-native-metrics/b40b79a-manifest-python.txt
tail -n +2 "$out/remaining-python-tests.tsv" | cut -f6 | sort > /tmp/forge-native-metrics/b40b79a-inventory-python.txt
cmp /tmp/forge-native-metrics/b40b79a-manifest-python.txt /tmp/forge-native-metrics/b40b79a-inventory-python.txt
n=0
while IFS=$'\t' read -r category named expanded dynamic physical path parse_error; do
  [[ "$category" == category ]] && continue
  [[ "$(git rev-parse "$old:$path")" == "$(git rev-parse "$new:$path")" ]]
  n=$((n+1))
done < "$out/remaining-python-tests.tsv"
[[ "$n" == 85 ]]
[[ "$(git diff --name-only "$old" "$new" -- '*.py')" == 'src/tooling/hooks/claude/test_hook_project_seam.py' ]]
[[ "$(awk -F '\t' '$6=="src/tooling/hooks/claude/test_hook_project_seam.py" {print $1,$2,$3,$5}' "$out/prior-14e570e-python-tests.tsv")" == 'executable_test 14 14 344' ]]
{
  printf 'commit=%s\n' "$new"
  printf 'python_test_manifest_paths=85/85\n'
  printf 'surviving_python_blob_oids_vs_14e570e=85/85\n'
  printf 'surviving_inventory_rows_from_prior_verified_pin=85/85\n'
  printf 'retired_executable_suite=src/tooling/hooks/claude/test_hook_project_seam.py named=14 static_expanded=14 physical_lines=344\n'
  awk -F '\t' 'NR>1 {c[$1]++; n[$1]+=$2; e[$1]+=$3; p[$1]+=$5} END {for (k in c) printf "%s: files=%d named=%d static_expanded=%d physical_lines=%d\n", k,c[k],n[k],e[k],p[k]}' "$out/remaining-python-tests.tsv" | sort
} > /tmp/forge-native-metrics/b40b79a-rederived-python-inventory-verification.txt
cmp "$out/python-inventory-verification.txt" /tmp/forge-native-metrics/b40b79a-rederived-python-inventory-verification.txt
