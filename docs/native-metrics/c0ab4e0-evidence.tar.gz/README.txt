Pinned native source SLOC measurement
=====================================

Source commit: c0ab4e080f661443085628d8035122b4e2823e92
Tree object: 45dd7ce076e95821bc93bead1ee9ea3690f89b5f
Git archive stream SHA-256: 324194d8f06a7ec168d21e0ba6e894c31dc4ee1142fb3c9c6df2d5d21bf0e3d0

This measures tracked Python, Rust, and shell source at the pinned commit,
using the unchanged path classification, Tokei 15.0.0, and syn-based
original-minus-masked inline Rust test treatment. It excludes current dirty
work. These percentages describe source composition, not runtime coverage,
behavioral coverage, or performance.

Production: Python 51,610 code lines; Rust 52,917; shell 194; native 50.5314%.
Tests: Python 26,936 code lines; Rust 71,993; Rust 72.7724%.
All tracked source including examples: Python 78,546; Rust 125,009; shell 194;
native 61.3544%.
Manifests: 375 production paths, 319 test paths, 696 counted source paths.
Two Rust example files with 99 code lines belong only to the all-source view.

The splitter found 100 test-only ranges in 85 production Rust files. Tokei
counts 43,180 Rust code lines in those original files and 30,121 after
masking, a 13,059-line test delta. Production Rust is 65,976 raw minus
13,059 inline-test lines = 52,917. Separate Rust test paths have 58,934
lines; adding the inline delta yields 71,993 Rust test lines.

Run the included measure-pinned.sh with the exact commit. It writes its
intermediates under /tmp/forge-native-metrics/c0ab4e0-archive-evidence.
The included verify-c0ab4e0.py independently classifies git ls-tree paths,
fetches every counted source with git cat-file --batch, checks SHA-256 and
archive bytes, re-runs the syn splitter on a separate archive extraction,
compares all 100 ranges and 85 masked/extracted copies, and re-runs Tokei
for every scope and per-file report. Its result is in
independent-verification.txt. Tokei's report array order varies, so reports
are compared by path and stats.

The archive includes NUL-delimited path manifests, all source hashes, exact
archive hash, raw Tokei JSON, AST ranges and counts, splitter source and
lockfile, both scripts, and executable/tool hashes. The source snapshot and
inline source copies are intentionally excluded; retrieve source by commit.

For independent reproduction, first run measure-pinned.sh to populate the
first evidence directory, then create a second extraction:

    mkdir -p /tmp/forge-native-metrics/c0ab4e0-independent/source
    git archive c0ab4e080f661443085628d8035122b4e2823e92 | tar -x -C /tmp/forge-native-metrics/c0ab4e0-independent/source
    python verify-c0ab4e0.py

The script uses the pinned tool paths recorded in tool-versions.txt and fails
on any manifest, blob, Tokei, splitter, or arithmetic mismatch.
