Pinned native source SLOC measurement
====================================

Source commit: 63c1bea0fa56d649d35aad10b44b05b8eec968f5
Tree object: cc086a9117fe200e8ef6b3212bb30804ea552e46
Measurement uses tracked Python, Rust, and shell source from a Git archive.
These are source composition metrics, not runtime coverage, behavioral
coverage, or performance claims.

Counts
------

Production: Python 51,296; Rust 51,599; shell 194; native share 50.0529%.
Tests: Python 35,383; Rust 51,546; Rust share 59.2967%.
All tracked source including examples: Python 86,679; Rust 103,244; shell
194; native share 54.3055%.
Manifests: 371 production files, 293 test files, 666 source files total.
The all-source view includes two Rust example files excluded from production
and test scopes.

The splitter identified 100 test-only Rust item ranges in 85 production Rust
files. Inline tests are counted as the original-minus-masked delta:
43,010 original inline-file Rust code lines minus 29,951 masked production
Rust code lines = 13,059. Production Rust is 64,658 raw lines minus 13,059
= 51,599. Rust tests are 38,487 separate Rust lines plus the same 13,059
inline lines = 51,546.

Reproduction
------------

Run the included measure-pinned.sh with the exact commit:

    ./measure-pinned.sh 63c1bea0fa56d649d35aad10b44b05b8eec968f5

The script writes intermediates under /tmp/forge-native-metrics/63c1bea-
archive-evidence. It uses Tokei 15.0.0 and forge-native-metric-split, obtains
tracked paths from Git, measures raw Tokei JSON, and attributes inline tests
from original-minus-masked Rust files. The Cargo manifest, lockfile, and
splitter source record the AST parser and dependency resolution. The Git
archive stream SHA-256 is recorded in archive-stream.sha256. All 666 source
file blobs were independently compared with the exact commit.

Evidence contents
-----------------

The package contains raw Tokei JSON for production, tests, all source, original
inline Rust files, and masked production Rust; NUL-delimited manifests; source
hashes; AST ranges; count summaries; tool versions and executable hashes; the
splitter source and lockfile; the reproduction script; and this README. The
extracted source snapshot and inline source-copy directories are excluded.
Retrieve source from Git by commit ID.
