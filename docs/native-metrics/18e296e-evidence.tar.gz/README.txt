Pinned native source SLOC measurement
====================================

Source commit: 18e296e81793d12ca1041a7cc8bf3d47ec719c84
Tree object: see `git rev-parse 18e296e^{tree}` at the source checkout.
Tracked Python, Rust, and shell source was measured from a Git archive using
unchanged path classification. These are source composition metrics, not
runtime coverage, behavioral coverage, or performance claims.

Counts
------

Production: Python 51,296; Rust 51,599; shell 194; native share 50.0529%.
Tests: Python 33,391; Rust 54,785; Rust share 62.1314%.
All tracked source including examples: Python 84,687; Rust 106,483; shell
194. Manifests: 371 production files, 295 test files, 668 source files total.
The all-source view includes two Rust example files excluded from production
and test scopes.

The splitter identified 100 test-only Rust item ranges in 85 production Rust
files. Inline tests use the original-minus-masked delta: 43,010 original
inline-file Rust code lines minus 29,951 masked production Rust code lines
= 13,059. Production Rust is 64,658 raw lines minus 13,059 = 51,599. Rust
tests are 41,726 separate Rust lines plus the same 13,059 inline lines
= 54,785.

Reproduction
------------

Run the included measurement script with the exact commit:

    ./measure-pinned.sh 18e296e81793d12ca1041a7cc8bf3d47ec719c84

The script writes intermediates under
`/tmp/forge-native-metrics/18e296e-archive-evidence`. It uses Tokei 15.0.0
and forge-native-metric-split, obtains tracked paths from Git, measures raw
Tokei JSON, and attributes inline tests from original-minus-masked Rust files.
The Cargo manifest, lockfile, and splitter source record the AST parser and
dependency resolution. The Git archive stream SHA-256 is recorded in
`archive-stream.sha256`. All 668 source file blobs were independently compared
with the exact commit; the per-file SHA-256 list is also included.

Evidence contents
-----------------

This package contains raw Tokei JSON for production, tests, all source,
original inline Rust files, and masked production Rust; NUL-delimited path
manifests; source hashes; AST ranges; count summaries; tool versions and
executable hashes; the splitter source and lockfile; the reproduction script;
and this README. The extracted source snapshot and inline source-copy
folders are excluded. Retrieve source from Git by commit ID.
