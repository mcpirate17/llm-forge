import ast
import csv
import hashlib
import subprocess
from pathlib import Path

root = Path('/tmp/forge-native-metrics/14e570e-archive-evidence')
snap = root / 'source'
old = list(csv.DictReader(open(root / 'prior-6ba6818-python-tests.tsv', newline=''), delimiter='\t'))
paths = {p.decode() for p in (root / 'test-source.paths0').read_bytes().split(b'\0') if p and p.endswith(b'.py')}
rows = [row for row in old if (snap / row['path']).is_file()]
assert len(rows) == len(paths) == 86
assert {row['path'] for row in rows} == paths
assert len(old) == 87
assert [row['path'] for row in old if row not in rows] == ['src/conductor/test_project_init.py']

class Unresolved(Exception):
    pass

def length(expr, constants):
    if isinstance(expr, (ast.List, ast.Tuple, ast.Set)):
        return len(expr.elts)
    if isinstance(expr, ast.Dict):
        return len(expr.keys)
    if isinstance(expr, ast.Name) and expr.id in constants:
        return length(constants[expr.id], constants)
    if isinstance(expr, ast.BinOp) and isinstance(expr.op, ast.Add):
        return length(expr.left, constants) + length(expr.right, constants)
    if isinstance(expr, ast.BinOp) and isinstance(expr.op, ast.Mult):
        if isinstance(expr.left, ast.Constant) and isinstance(expr.left.value, int):
            return expr.left.value * length(expr.right, constants)
        if isinstance(expr.right, ast.Constant) and isinstance(expr.right.value, int):
            return expr.right.value * length(expr.left, constants)
    if isinstance(expr, ast.Call) and isinstance(expr.func, ast.Name):
        if expr.func.id in ('tuple', 'list', 'set', 'sorted') and len(expr.args) == 1:
            return length(expr.args[0], constants)
        if expr.func.id == 'range':
            args = [ast.literal_eval(x) for x in expr.args]
            return len(range(*args))
    if isinstance(expr, ast.Call) and isinstance(expr.func, ast.Attribute) and expr.func.attr in ('values', 'keys', 'items') and not expr.args:
        return length(expr.func.value, constants)
    raise Unresolved(ast.dump(expr))

def parameter_cases(node, constants):
    count = 1
    for deco in node.decorator_list:
        if not isinstance(deco, ast.Call) or len(deco.args) < 2:
            continue
        target = deco.func
        if isinstance(target, ast.Attribute) and target.attr == 'parametrize':
            count *= length(deco.args[1], constants)
    return count

counts = {}
for row in rows:
    path = row['path']
    raw = (snap / path).read_bytes()
    tree = ast.parse(raw, filename=path)
    constants = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    constants[target.id] = node.value
    tests = [node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test_')]
    named = len(tests)
    try:
        expanded = sum(parameter_cases(node, constants) for node in tests)
    except Unresolved as exc:
        raise AssertionError((path, exc)) from exc
    physical = len(raw.splitlines())
    assert (named, expanded, physical) == (int(row['named']), int(row['static_expanded_cases']), int(row['physical_lines'])), (path, named, expanded, physical, row)
    previous = subprocess.run(['git', 'show', f'6ba68187ffedb4984f32f8f85b0c5a1370efefdc:{path}'], cwd='/home/tim/Projects/llm-forge', capture_output=True, check=True).stdout
    assert hashlib.sha256(previous).digest() == hashlib.sha256(raw).digest(), path
    counts[row['category']] = counts.get(row['category'], (0,0,0,0))
    a,b,c,d = counts[row['category']]
    counts[row['category']] = (a+1,b+named,c+expanded,d+physical)
with open(root / 'remaining-python-tests.tsv', 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=old[0].keys(), delimiter='\t')
    writer.writeheader()
    writer.writerows(rows)
assert counts == {'executable_test': (53,843,933,21958), 'fixture_input': (32,14,14,133), 'shared_conftest': (1,0,0,270)}
with open(root / 'python-inventory-verification.txt', 'w') as f:
    f.write('commit=14e570e6c7d2798a1ef9586c0f4e04863bc28a0d\n')
    f.write('python_test_manifest_paths=86/86\n')
    f.write('surviving_python_blob_hashes_vs_6ba6818=86/86\n')
    f.write('python_ast_named_expanded_physical_rows=86/86\n')
    f.write('retired_executable_suite=src/conductor/test_project_init.py named=38 expanded=38\n')
    for kind, (files,named,expanded,physical) in counts.items():
        f.write(f'{kind}: files={files} named={named} static_expanded={expanded} physical_lines={physical}\n')
print((root / 'python-inventory-verification.txt').read_text(),end='')
