Pinned native migration measurement: eeb30d5dd2c7956918d0b62067d002faa8ec10d9

Run measure-pinned.sh COMMIT to reproduce the source count from a plain Git
archive. This script is byte-identical to the 8d71bca evidence version; its
path classification and Tokei 15.0.0/syn splitter are unchanged. Python,
Rust and shell production source and Python/Rust test source are separated by
NUL-delimited path manifests. Rust inline test items are attributed by the
original-minus-masked full-file count. Examples appear only in all-source.

verify-eeb30d5.sh performs a second Git archive extraction, checks the SHA-256
of every counted source against its independent Git blob, reconstructs the
manifests and AST ranges, compares all 87 masked and extracted Rust source
copies, and repeats per-file Tokei reports. The source and inline copies are
omitted from this compact bundle; these scripts regenerate them under /tmp.
The independent-verification.txt receipt summarizes those exact checks.

verify-eeb30d5-python.py compares the 8d71bca prior inventory with the
pinned tree, checks exactly five Python test deletions, all 47 surviving Python
test/fixture blob IDs and AST counts, and emits the 124 retired / 337 remaining
static case inventory. verify-eeb30d5-case-map.py checks the three committed
migration maps, all 93 original test-function expansion frequencies, all 124
unique original labels, and all 124 Rust test names, including macro-generated
test functions. The map and source hashes are included. This verifies mapping
and executable naming; the scoped logs record observed test outcomes.

The logs are phase-labeled. Doctor, tooling-boundary and mutation-attribution
Rust test logs were produced on the staged source before the 0.1.68 version
bump. The combined packaging 64-case run preceded the resource fixture purity
repair; the separate 23 resource and one installed-layout runs followed that
repair. The committed source integration log covers discovery 29/29 and
attribution 26/26 at v0.1.68. The 303 remaining Python cases were collected,
not executed. The 34-case torch-dependent module remains in the static count
but calls pytest.importorskip("torch") in this Forge environment.

No matched performance experiment was run for this cohort. The 134-case matched
Python/Rust harness benchmark belongs to the prior 8d71bca evidence and is
preserved there. The resource target's 3.00-second scoped test duration has no
matched comparison and is not a speed measurement. The full local-check and
local-verify gate was pending when this evidence was assembled.
