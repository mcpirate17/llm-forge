#!/usr/bin/env python3
"""Verify pinned Python suite retirement by Git blobs and static AST."""
from __future__ import annotations

import ast
import csv
import io
import subprocess
import tarfile
from pathlib import Path

REPO = Path("/home/tim/Projects/llm-forge")
OLD = "8d71bca853c0e3f83d0747ea9bb317338356df48"
NEW = "eeb30d5dd2c7956918d0b62067d002faa8ec10d9"
OUT = Path("/tmp/forge-native-metrics/eeb30d5-archive-evidence")
ARCHIVE = REPO / "docs/native-metrics/8d71bca-evidence.tar.gz"
STEMS = ("doctor", "package_resources", "installed_layout", "tooling_boundary", "mutation_attribution")
EXPECTED = {f"src/conductor/test_{stem}.py" for stem in STEMS}


def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=REPO, text=True).strip()


def source_at(commit: str, path: str) -> str:
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=REPO).decode()


def counts(source: str, path: str) -> tuple[int, int]:
    tree = ast.parse(source, filename=path)
    names = {
        node.targets[0].id: node.value
        for node in tree.body
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
    }
    tests = [
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name.startswith("test_")
    ]
    expanded = 0
    for test in tests:
        variants = 1
        for decorator in test.decorator_list:
            if not (
                isinstance(decorator, ast.Call)
                and isinstance(decorator.func, ast.Attribute)
                and decorator.func.attr == "parametrize"
            ):
                continue
            values = decorator.args[1]
            if isinstance(values, (ast.List, ast.Tuple, ast.Set)):
                length = len(values.elts)
            elif isinstance(values, ast.Name) and isinstance(
                names.get(values.id), (ast.List, ast.Tuple, ast.Set)
            ):
                length = len(names[values.id].elts)
            elif (
                isinstance(values, ast.Call)
                and isinstance(values.func, ast.Name)
                and values.func.id == "sorted"
                and isinstance(values.args[0], ast.Call)
                and isinstance(values.args[0].func, ast.Attribute)
                and values.args[0].func.attr == "values"
                and isinstance(values.args[0].func.value, ast.Name)
            ):
                mapping = names[values.args[0].func.value.id]
                assert isinstance(mapping, ast.Dict)
                length = len(mapping.keys)
            else:
                raise AssertionError(f"unhandled parametrization {path}:{test.lineno}")
            variants *= length
        expanded += variants
    return len(tests), expanded


with tarfile.open(ARCHIVE, "r:gz") as bundle:
    prior = bundle.extractfile("./remaining-python-tests.tsv")
    assert prior is not None
    rows = list(csv.DictReader(io.TextIOWrapper(prior), delimiter="\t"))
assert len(rows) == 52
manifest = {
    path.decode()
    for path in (OUT / "test-source.paths0").read_bytes().split(b"\0")
    if path.endswith(b".py")
}
retired = [row for row in rows if row["path"] in EXPECTED]
surviving = [row for row in rows if row["path"] not in EXPECTED]
assert {row["path"] for row in retired} == EXPECTED
assert len(retired) == 5 and len(surviving) == 47
assert manifest == {row["path"] for row in surviving}
assert all(row["category"] == "executable_test" for row in retired)
for row in surviving:
    path = row["path"]
    assert git("rev-parse", f"{OLD}:{path}") == git("rev-parse", f"{NEW}:{path}"), path
    source = (OUT / "source" / path).read_text()
    assert len(source.splitlines()) == int(row["physical_lines"]), path
    if row["category"] == "executable_test":
        assert counts(source, path) == (
            int(row["named"]), int(row["static_expanded_cases"])
        ), path
for row in retired:
    path = row["path"]
    source = source_at(OLD, path)
    assert len(source.splitlines()) == int(row["physical_lines"]), path
    assert counts(source, path) == (
        int(row["named"]), int(row["static_expanded_cases"])
    ), path

changes = git("diff", "--name-status", OLD, NEW, "--", "*.py").splitlines()
assert sorted(changes) == sorted(f"D\t{path}" for path in EXPECTED), changes
assert sum(int(row["static_expanded_cases"]) for row in retired) == 124
category_counts = {
    category: sum(row["category"] == category for row in surviving)
    for category in ("executable_test", "fixture_input", "shared_conftest")
}
assert category_counts == {
    "executable_test": 12, "fixture_input": 34, "shared_conftest": 1
}, category_counts
fieldnames = list(rows[0])
for filename, group in (
    ("remaining-python-tests.tsv", surviving),
    ("retired-python-tests.tsv", retired),
):
    with (OUT / filename).open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t")
        writer.writeheader()
        writer.writerows(group)
retired_named = sum(int(row["named"]) for row in retired)
retired_lines = sum(int(row["physical_lines"]) for row in retired)
remaining_named = sum(int(row["named"]) for row in surviving if row["category"] == "executable_test")
remaining_expanded = sum(int(row["static_expanded_cases"]) for row in surviving if row["category"] == "executable_test")
summary = (
    f"commit={NEW}\nprior_commit={OLD}\n"
    f"retired_executable_suites=5 named={retired_named} static_expanded=124 physical_lines={retired_lines}\n"
    f"remaining_executable_suites=12 named={remaining_named} static_expanded={remaining_expanded}\n"
    "remaining_fixture_inputs=34 shared_conftest=1\n"
    "surviving_python_test_fixture_blob_oids=47/47 unchanged\n"
    "surviving_python_test_manifest_paths=47/47 exact\n"
    "surviving_executable_ast_counts=12/12 exact\n"
    "retired_executable_ast_counts=5/5 exact\n"
    "python_source_diff=5_test_deletions_exact\n"
)
(OUT / "python-inventory-verification.txt").write_text(summary)
print(summary, end="")
