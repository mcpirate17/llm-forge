#!/usr/bin/env python3
"""Check the pinned five-suite retirement inventory and native case maps."""
from __future__ import annotations

import ast
import csv
import hashlib
import re
import subprocess
from collections import Counter
from pathlib import Path

REPO = Path('/home/tim/Projects/llm-forge')
OLD = '8d71bca853c0e3f83d0747ea9bb317338356df48'
NEW = 'eeb30d5dd2c7956918d0b62067d002faa8ec10d9'
OUT = Path('/tmp/forge-native-metrics/eeb30d5-archive-evidence')
SOURCE = OUT / 'source'
COHORTS = (
    ('native-doctor-contract-migration.md', ('doctor',)),
    ('native-packaging-contract-migration.md', ('package_resources', 'installed_layout', 'tooling_boundary')),
    ('native-mutation-attribution-contract-migration.md', ('mutation_attribution',)),
)
EXPECTED_COUNTS = {'doctor': 34, 'package_resources': 23, 'installed_layout': 1,
                   'tooling_boundary': 40, 'mutation_attribution': 26}


def git_bytes(commit: str, path: str) -> bytes:
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=REPO)


def variants_by_test(source: bytes, path: str) -> dict[str, int]:
    tree = ast.parse(source, filename=path)
    names = {
        node.targets[0].id: node.value
        for node in tree.body
        if isinstance(node, ast.Assign) and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
    }
    results = {}
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or not node.name.startswith('test_'):
            continue
        variants = 1
        for decorator in node.decorator_list:
            if not (isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute)
                    and decorator.func.attr == 'parametrize'):
                continue
            value = decorator.args[1]
            if isinstance(value, (ast.List, ast.Tuple, ast.Set)):
                count = len(value.elts)
            elif isinstance(value, ast.Name) and isinstance(names.get(value.id), (ast.List, ast.Tuple, ast.Set)):
                count = len(names[value.id].elts)
            elif (isinstance(value, ast.Call) and isinstance(value.func, ast.Name)
                  and value.func.id == 'sorted' and isinstance(value.args[0], ast.Call)
                  and isinstance(value.args[0].func, ast.Attribute)
                  and value.args[0].func.attr == 'values'
                  and isinstance(value.args[0].func.value, ast.Name)):
                mapping = names[value.args[0].func.value.id]
                assert isinstance(mapping, ast.Dict)
                count = len(mapping.keys)
            else:
                raise AssertionError(f'unhandled parametrization {path}:{node.lineno}')
            variants *= count
        results[node.name] = variants
    return results


def rust_names(source: str) -> set[str]:
    direct = re.findall(r'^#\[test\]\nfn (\w+)\(', source, re.M)
    expanded = re.findall(r'^\w+_case!\(\s*(\w+)', source, re.M)
    names = direct + expanded
    assert len(names) == len(set(names)), 'duplicate Rust test name'
    return set(names)


rows_all: list[dict[str, str]] = []
source_hashes: list[tuple[str, str]] = []
summary = []
for doc, stems in COHORTS:
    doc_path = f'docs/{doc}'
    doc_source = (SOURCE / doc_path).read_bytes()
    source_hashes.append((hashlib.sha256(doc_source).hexdigest(), f'{NEW}:{doc_path}'))
    rows = re.findall(r'^\| `(test_[^`]+)` \| `([^`]+)` \|$', doc_source.decode(), re.M)
    assert len(rows) == sum(EXPECTED_COUNTS[stem] for stem in stems), doc
    at = 0
    for stem in stems:
        count = EXPECTED_COUNTS[stem]
        mapping = rows[at:at + count]
        at += count
        original = f'src/conductor/test_{stem}.py'
        rust = f'native/conductor-native/tests/python_contracts_{stem}.rs'
        old_source = git_bytes(OLD, original)
        new_source = (SOURCE / rust).read_bytes()
        source_hashes.append((hashlib.sha256(old_source).hexdigest(), f'{OLD}:{original}'))
        source_hashes.append((hashlib.sha256(new_source).hexdigest(), f'{NEW}:{rust}'))
        expected = variants_by_test(old_source, original)
        bases = Counter(re.split(r'[\[(]', case, 1)[0] for case, _ in mapping)
        assert bases == expected, (stem, bases, expected)
        mapped_names = [case for _, case in mapping]
        assert len(mapped_names) == len(set(mapped_names)), stem
        actual_names = rust_names(new_source.decode())
        assert actual_names == set(mapped_names), (stem, sorted(actual_names - set(mapped_names)), sorted(set(mapped_names) - actual_names))
        original_labels = [case for case, _ in mapping]
        assert len(original_labels) == len(set(original_labels)), stem
        for original_case, rust_case in mapping:
            rows_all.append({'original_file': original, 'original_case': original_case,
                             'rust_target': f'python_contracts_{stem}', 'rust_case': rust_case})
        summary.append(f'{stem}: original_named={len(expected)} expanded={sum(expected.values())} map_rows={len(mapping)} rust_tests={len(actual_names)}')
    assert at == len(rows), doc
assert len(rows_all) == 124
with (OUT / 'rust-contract-case-map.tsv').open('w', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows_all[0]), delimiter='\t')
    writer.writeheader()
    writer.writerows(rows_all)
(OUT / 'case-map-source-sha256.txt').write_text(''.join(f'{digest}  {path}\n' for digest, path in source_hashes))
receipt = (f'commit={NEW}\noriginal_parent={OLD}\n'
           'original_expanded_cases=124/124 exact\n'
           'native_test_functions=124/124 exact\n'
           'mapped_case_rows=124/124 exact\n'
           'original_named_functions=93/93 exact\n'
           'original_base_frequency=93/93 exact\n'
           'unique_original_labels=124/124 exact\n'
           'unique_native_names=124/124 exact\n'
           + '\n'.join(summary) + '\n')
(OUT / 'case-map-verification.txt').write_text(receipt)
print(receipt, end='')
