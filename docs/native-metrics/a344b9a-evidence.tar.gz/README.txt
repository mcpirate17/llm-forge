Pinned native source SLOC measurement
=====================================

Source commit: a344b9ab8c1b432f2429fd01924b4d6c1bffb688
Tree object: e29affb74737f905b5fcd4185b2565402d0c0404
Git archive stream SHA-256: 5d8c4525c81da7f3a4c42332d225e331117fb1962bbd0908fc176892e2e405f7

This measures tracked Python, Rust, and shell source at the pinned commit,
using the unchanged path classification, Tokei 15.0.0, and syn-based
original-minus-masked inline Rust test treatment. It excludes current dirty
work. These percentages describe source composition, not runtime coverage,
behavioral coverage, or performance.

Production: Python 51,610 code lines; Rust 52,954; shell 194; native 50.5489%.
Tests: Python 21,005 code lines; Rust 83,694; Rust 79.9377%.
All tracked source including examples: Python 72,615; Rust 136,747; shell 194;
native 65.2556%.
Manifests: 375 production paths, 343 test paths, 720 counted source paths.
Two Rust example files with 99 code lines belong only to the all-source view.

The splitter found 100 test-only ranges in 85 production Rust files. Tokei
counts 43,180 Rust code lines in those original files and 30,121 after
masking, a 13,059-line test delta. Production Rust is 66,013 raw minus
13,059 inline-test lines = 52,954. Separate Rust test paths have 70,635
lines; adding the inline delta yields 83,694 Rust test lines.

Run the included measure-pinned.sh with the exact commit. It writes its
intermediates under /tmp/forge-native-metrics/a344b9a-archive-evidence.
The included verify-a344b9a.py independently classifies git ls-tree paths,
fetches every counted source with git cat-file --batch, checks SHA-256 and
archive bytes, re-runs the syn splitter on a separate archive extraction,
compares all 100 ranges and 85 masked/extracted copies, and re-runs Tokei
for every scope and per-file report. Its result is in
independent-verification.txt. Tokei's report array order varies, so reports
are compared by path and stats.

The archive includes NUL-delimited path manifests, all source hashes, exact
archive hash, raw Tokei JSON, AST ranges and counts, splitter source and
lockfile, both scripts, and executable/tool hashes. The source snapshot and
inline source copies are intentionally excluded; retrieve source by commit.

For independent reproduction, first run measure-pinned.sh to populate the
first evidence directory, then create a second extraction:

    mkdir -p /tmp/forge-native-metrics/a344b9a-independent/source
    git archive a344b9ab8c1b432f2429fd01924b4d6c1bffb688 | tar -x -C /tmp/forge-native-metrics/a344b9a-independent/source
    python verify-a344b9a.py

The script uses the pinned tool paths recorded in tool-versions.txt and fails
on any manifest, blob, Tokei, splitter, or arithmetic mismatch.
