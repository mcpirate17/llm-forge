Pinned source-composition evidence for 15be2ad01e66f8e57606187a66ff8708efe965f6.

measure-pinned.sh reproduces the committed path classification and Tokei 15.0.0
plus syn inline-test split from a plain Git archive. verify-pinned.sh independently
extracts a second archive, checks all 786 counted paths against their Git blobs,
rebuilds all classified manifests and source hashes, repeats per-file Tokei,
recomputes AST ranges and all 88 masked Rust files, and checks raw count arithmetic.
It writes scratch output under /tmp/forge-native-metrics and does not edit source.
The source and masked copies are regenerated from the pinned archive.

The source-content manifest SHA-256 is recorded in source-content-sha256.txt and
metrics input hashes. The archived Git stream SHA-256 is recorded in
archive-stream.sha256. Path-manifest hashes are in path-manifest-sha256.txt.

The three maps contain 142 static cases across six suites: 140 Rust counterparts
were added in this cohort and two hook-corpus Rust cases were already present.
python-source-diff.tsv records the final suite and conftest retirements. The
remaining Python test source paths list explicit fixture/input programs.

Validation logs are phase-labeled. Candidate-flow and mutation contract logs
record their scoped targets. The post-retirement target log records 191 passes
across 21 targets, including the final runtime A/B targets; separate runtime
and mutation mapping validation totals are preserved in the committed maps.
Final-source integration and entrypoint Clippy passed. Entrypoint packaging
reported three passes and one deliberately ignored installed-runtime smoke test;
that smoke remains part of the pending full gate. The benchmark target's four
unit tests passed; no speed comparison was run for this cohort. The full local
gate and full make test timing remain pending.
