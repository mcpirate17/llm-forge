Pinned native source SLOC measurement
====================================

Source commit: 8eb7c76b909f2da7e1d5e1847eb53904332fb293
Measurement: tracked Python, Rust, and shell source from `git archive`.
No runtime coverage, behavioral coverage, or performance claim is made.

Counts
------

Production: Python 51,296; Rust 51,599; shell 194; Rust share 50.0529%.
Tests: Python 40,566; Rust 41,398; Rust share 50.5075%.
All source including examples: Python 91,862; Rust 93,096; shell 194.
Manifests: 371 production files, 295 test files, 668 source files total.

The splitter identified 100 test-only Rust item ranges in 85 production Rust
files. The original-minus-masked code-line delta is 13,059. Production Rust is
64,658 raw lines minus 13,059 inline-test lines = 51,599. Rust tests are 28,339
separate Rust lines plus the same 13,059 inline-test lines = 41,398.

Reproduction
------------

Run the included `measure-pinned.sh` with the exact source commit:

    ./measure-pinned.sh 8eb7c76b909f2da7e1d5e1847eb53904332fb293

The script writes its working snapshot and intermediates under
`/tmp/forge-native-metrics/8eb7c76-archive-evidence`. It requires the pinned
Tokei 15.0.0 binary and `forge-native-metric-split` tool. It derives the
manifests from `git ls-tree`, extracts a `git archive`, measures raw Tokei JSON,
and removes inline test code by the original-minus-masked method. The included
Cargo manifest/lock/source record the splitter implementation and dependency
resolution. The archive stream SHA-256 is recorded in
`archive-stream.sha256`; all 668 source file hashes independently matched
`git show <commit>:<path>` blob contents.

Evidence contents
-----------------

The package contains raw Tokei JSON for production, tests, all source, original
inline Rust files, and masked production Rust; NUL-delimited manifests; source
hashes; AST ranges; count summaries; tool versions and executable hashes; the
splitter source and lockfile; the full reproduction script; and this README.
Extracted source snapshots and inline source-copy directories are intentionally
not included. The source commit can be retrieved from Git using the recorded
commit ID.
