Pinned native source SLOC measurement
====================================

Source commit: b49591d5ddaed896c91ab5df398e59dce0f78c0d
Tree object: 201a651150e24110c80c085841a862d370b638a0
Git archive stream SHA-256: ce0250abf420411a1cc1dbe77c186919dc7a305b8844d6700f3b8a4a8b08666f

This measures tracked Python, Rust, and shell source at the pinned commit,
using the unchanged path classification, Tokei 15.0.0, and syn-based
original-minus-masked inline Rust test treatment. It excludes current dirty
work. These percentages describe source composition, not runtime coverage,
behavioral coverage, or performance.

Production: Python 51,577 code lines; Rust 52,892; shell 194; native 50.5355%.
Tests: Python 31,406 code lines; Rust 60,904; Rust 65.9777%.
All tracked source including examples: Python 82,983; Rust 113,895; shell 194.
Manifests: 375 production paths, 301 test paths, 678 counted source paths.
Two Rust example files with 99 code lines belong only to the all-source view.

The splitter found 100 test-only ranges in 85 production Rust files. Tokei
counts 43,180 Rust code lines in those original files and 30,121 after
masking, a 13,059-line test delta. Production Rust is 65,951 raw minus
13,059 inline-test lines = 52,892. Separate Rust test paths have 47,845
lines; adding the inline delta yields 60,904 Rust test lines.

Run the included measure-pinned.sh with the exact commit. It writes its
intermediates under /tmp/forge-native-metrics/b49591d-archive-evidence.
The included verify-b49591d.py independently classifies git ls-tree paths,
fetches every counted source with git cat-file --batch, checks SHA-256 and
archive bytes, re-runs the syn splitter on a separate archive extraction,
compares all 100 ranges and 85 masked/extracted copies, and re-runs Tokei
for every scope and per-file report. Its result is in
independent-verification.txt. Tokei's report array order varies, so reports
are compared by path and stats.

The archive includes NUL-delimited path manifests, all source hashes, exact
archive hash, raw Tokei JSON, AST ranges and counts, splitter source and
lockfile, both scripts, and executable/tool hashes. The source snapshot and
inline source copies are intentionally excluded; retrieve source by commit.

For the independent verification script, first run measure-pinned.sh to
populate the first evidence directory, then create a second extraction:

    mkdir -p /tmp/forge-native-metrics/b49591d-independent/source
    git archive b49591d5ddaed896c91ab5df398e59dce0f78c0d | tar -x -C /tmp/forge-native-metrics/b49591d-independent/source
    python verify-b49591d.py

The script uses the pinned tool paths recorded in tool-versions.txt and fails
on any manifest, blob, Tokei, splitter, or arithmetic mismatch.
