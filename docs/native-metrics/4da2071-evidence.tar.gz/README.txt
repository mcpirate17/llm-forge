Pinned native source SLOC measurement
====================================

Source commit: 4da207110e81697b1591a08285285598f7b8991a
Tree object: 58a0ea485f2c45364e59b0efb00604b04cc82b9f
Git archive stream SHA-256: ed11a393ebabbe7ac2a4cb8db50f1de290dfa33739c1136a1215528bc8dd5e78

This measures tracked Python, Rust, and shell source at the pinned commit,
using the unchanged path classification, Tokei 15.0.0, and syn-based
original-minus-masked inline Rust test treatment. It excludes current dirty
work. These percentages describe source composition, not runtime coverage,
behavioral coverage, or performance.

Production: Python 51,610 code lines; Rust 52,909; shell 194; native 50.5276%.
Tests: Python 27,948 code lines; Rust 69,657; Rust 71.3662%.
All tracked source including examples: Python 79,558; Rust 122,665; shell 194;
native 60.6001%.
Manifests: 375 production paths, 315 test paths, 692 counted source paths.
Two Rust example files with 99 code lines belong only to the all-source view.

The splitter found 100 test-only ranges in 85 production Rust files. Tokei
counts 43,180 Rust code lines in those original files and 30,121 after
masking, a 13,059-line test delta. Production Rust is 65,968 raw minus
13,059 inline-test lines = 52,909. Separate Rust test paths have 56,598
lines; adding the inline delta yields 69,657 Rust test lines.

Run the included measure-pinned.sh with the exact commit. It writes its
intermediates under /tmp/forge-native-metrics/4da2071-archive-evidence.
The included verify-4da2071.py independently classifies git ls-tree paths,
fetches every counted source with git cat-file --batch, checks SHA-256 and
archive bytes, re-runs the syn splitter on a separate archive extraction,
compares all 100 ranges and 85 masked/extracted copies, and re-runs Tokei
for every scope and per-file report. Its result is in
independent-verification.txt. Tokei's report array order varies, so reports
are compared by path and stats.

The archive includes NUL-delimited path manifests, all source hashes, exact
archive hash, raw Tokei JSON, AST ranges and counts, splitter source and
lockfile, both scripts, and executable/tool hashes. The source snapshot and
inline source copies are intentionally excluded; retrieve source by commit.

For independent reproduction, first run measure-pinned.sh to populate the
first evidence directory, then create a second extraction:

    mkdir -p /tmp/forge-native-metrics/4da2071-independent/source
    git archive 4da207110e81697b1591a08285285598f7b8991a | tar -x -C /tmp/forge-native-metrics/4da2071-independent/source
    python verify-4da2071.py

The script uses the pinned tool paths recorded in tool-versions.txt and fails
on any manifest, blob, Tokei, splitter, or arithmetic mismatch.
