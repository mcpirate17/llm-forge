use proc_macro2::Span;
use std::{env, fs, io, path::{Path, PathBuf}};
use syn::{spanned::Spanned, Attribute, File, ImplItem, Item, TraitItem};

#[derive(Clone, Copy, Debug)]
struct Range { start: usize, end: usize }

fn requires_test(meta: &syn::Meta) -> bool {
    match meta {
        syn::Meta::Path(path) => path.is_ident("test"),
        syn::Meta::List(list) if list.path.is_ident("all") => {
            let metas = syn::parse::Parser::parse2(
                syn::punctuated::Punctuated::<syn::Meta, syn::Token![,]>::parse_terminated,
                list.tokens.clone(),
            ).unwrap_or_default();
            metas.iter().any(requires_test)
        }
        syn::Meta::List(list) if list.path.is_ident("any") => {
            let metas = syn::parse::Parser::parse2(
                syn::punctuated::Punctuated::<syn::Meta, syn::Token![,]>::parse_terminated,
                list.tokens.clone(),
            ).unwrap_or_default();
            !metas.is_empty() && metas.iter().all(requires_test)
        }
        syn::Meta::List(list) if list.path.is_ident("not") => false,
        _ => false,
    }
}
fn is_test_cfg(attrs: &[Attribute]) -> bool {
    attrs.iter().any(|a| {
        if !a.path().is_ident("cfg") { return false; }
        let syn::Meta::List(list) = &a.meta else { return false; };
        let metas = syn::parse::Parser::parse2(
            syn::punctuated::Punctuated::<syn::Meta, syn::Token![,]>::parse_terminated,
            list.tokens.clone(),
        ).unwrap_or_default();
        metas.iter().any(requires_test)
    })
}
fn is_test_attr(attrs: &[Attribute]) -> bool {
    attrs.iter().any(|a| a.path().segments.last().is_some_and(|s| s.ident == "test"))
}
fn span_range(span: Span, starts: &[usize], len: usize) -> Range {
    let start = span.start(); let end = span.end();
    let offset = |line: usize, col: usize| -> usize {
        let base = starts.get(line.saturating_sub(1)).copied().unwrap_or(len);
        (base + col).min(len)
    };
    Range { start: offset(start.line, start.column), end: offset(end.line, end.column).max(offset(start.line, start.column)) }
}
fn item_attrs(item: &Item) -> &[Attribute] { match item {
    Item::Const(x)=>&x.attrs, Item::Enum(x)=>&x.attrs, Item::ExternCrate(x)=>&x.attrs, Item::Fn(x)=>&x.attrs,
    Item::ForeignMod(x)=>&x.attrs, Item::Impl(x)=>&x.attrs, Item::Macro(x)=>&x.attrs, Item::Mod(x)=>&x.attrs,
    Item::Static(x)=>&x.attrs, Item::Struct(x)=>&x.attrs, Item::Trait(x)=>&x.attrs, Item::TraitAlias(x)=>&x.attrs,
    Item::Type(x)=>&x.attrs, Item::Union(x)=>&x.attrs, Item::Use(x)=>&x.attrs, _=>&[],
}}
fn impl_attrs(item: &ImplItem) -> &[Attribute] { match item {
    ImplItem::Const(x)=>&x.attrs, ImplItem::Fn(x)=>&x.attrs, ImplItem::Macro(x)=>&x.attrs, ImplItem::Type(x)=>&x.attrs, _=>&[],
}}
fn trait_attrs(item: &TraitItem) -> &[Attribute] { match item {
    TraitItem::Const(x)=>&x.attrs, TraitItem::Fn(x)=>&x.attrs, TraitItem::Macro(x)=>&x.attrs, TraitItem::Type(x)=>&x.attrs, _=>&[],
}}
struct Collect { ranges: Vec<Range>, starts: Vec<usize>, len: usize }
impl Collect {
    fn push(&mut self, span: Span) { self.ranges.push(span_range(span, &self.starts, self.len)); }
    fn walk_items(&mut self, items: &[Item]) {
        for item in items {
            let attrs=item_attrs(item);
            if is_test_cfg(attrs) || (matches!(item, Item::Fn(_)) && is_test_attr(attrs)) { self.push(item.span()); continue; }
            match item {
                Item::Mod(m) => if let Some((_, nested))=&m.content { self.walk_items(nested); },
                Item::Impl(i) => for child in &i.items { if is_test_cfg(impl_attrs(child)) || (matches!(child, ImplItem::Fn(_)) && is_test_attr(impl_attrs(child))) { self.push(child.span()); } },
                Item::Trait(t) => for child in &t.items { if is_test_cfg(trait_attrs(child)) || (matches!(child, TraitItem::Fn(_)) && is_test_attr(trait_attrs(child))) { self.push(child.span()); } },
                _=>{},
            }
        }
    }
}
fn line_starts(s: &str) -> Vec<usize> { let mut v=vec![0]; for (i,b) in s.bytes().enumerate() { if b==b'\n' { v.push(i+1); } } v }
fn write(path: &Path, text: &str) -> io::Result<()> { if let Some(p)=path.parent(){fs::create_dir_all(p)?;} fs::write(path,text) }
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args:Vec<String>=env::args().collect(); if args.len()!=6 { eprintln!("ROOT MANIFEST0 PROD_DIR TEST_DIR RANGES"); std::process::exit(2); }
    let root=PathBuf::from(&args[1]); let manifest=fs::read(&args[2])?; let prodroot=PathBuf::from(&args[3]); let testroot=PathBuf::from(&args[4]); let mut range_out=String::new();
    let mut modules=0usize; let mut fragments=0usize;
    for raw in manifest.split(|b|*b==0).filter(|s|!s.is_empty()) {
        let rel=std::str::from_utf8(raw)?; if !rel.ends_with(".rs") { continue; }
        let source=fs::read_to_string(root.join(rel))?; let parsed:File=syn::parse_file(&source).map_err(|e|format!("{}: {e}",rel))?; let starts=line_starts(&source);
        let mut c=Collect{ranges:Vec::new(),starts,len:source.len()}; c.walk_items(&parsed.items); c.ranges.sort_by_key(|r|r.start);
        let mut merged:Vec<Range>=Vec::new(); for r in c.ranges { if r.end<=r.start {continue;} if let Some(last)=merged.last_mut(){if r.start<=last.end {last.end=last.end.max(r.end);continue;}} merged.push(r); }
        if merged.is_empty(){continue;} modules+=merged.len();
        let mut prod=source.clone(); let mut tests=String::new();
        for r in merged.iter().rev(){ tests.insert_str(0,&source[r.start..r.end]); tests.insert(0,'\n'); for b in unsafe { prod.as_bytes_mut() }[r.start..r.end].iter_mut(){if *b!=b'\n'{*b=b' ';}} }
        for r in &merged { let start=source[..r.start].bytes().filter(|b|*b==b'\n').count()+1; let end=source[..r.end].bytes().filter(|b|*b==b'\n').count()+1; range_out.push_str(&format!("{}\t{}\t{}\n",rel,start,end)); }
        write(&prodroot.join(rel),&prod)?; write(&testroot.join(rel),&tests)?; fragments+=1;
    }
    fs::write(&args[5],range_out)?; println!("inline_test_ranges={modules} rust_files_with_ranges={fragments}"); Ok(())
}
