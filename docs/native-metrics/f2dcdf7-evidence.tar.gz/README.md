# Native source measurement at f2dcdf7

Commit: f2dcdf776e3cb167006bf5bdb20cd31c165cfe1f.

The source was extracted with `git archive`; the counted source content hash
manifest also matches an independent extraction using `git show` for each blob.
Uncommitted changes and untracked files are excluded.

The three NUL-delimited path manifests classify 354 production files, 281 test
files, and 637 source files overall. The overall scope includes two Rust example
files (99 code lines), which are excluded from production and tests.

Production: Python 52,384; Rust 48,045; shell 194; native share 47.7475%.
Tests: Python 42,101; Rust 37,465; Rust share 47.0867%.

The Rust AST splitter found 94 test-only ranges in 79 production Rust files.
Those same 79 files contain 40,889 original code lines and 28,346 after masking,
so the inline test delta is 12,543. All production Rust before masking contains
60,588 lines; subtracting the delta gives 48,045 production Rust lines. The
separate test-path manifest contains 24,922 Rust lines; adding the delta gives
37,465 Rust test lines. These scopes are additive.

`measure-pinned.sh` records the extraction, classification, Tokei calls, and
arithmetic. The raw JSON, source hashes, manifests, AST ranges, splitter source
and dependency lockfile, and tool identity hashes are included. To reproduce,
provide Tokei 15.0.0 and build the included splitter with its Cargo manifest and
lockfile, then adjust the script's tool and repository paths. Source composition
does not measure runtime coverage, behavior coverage, or speed.
