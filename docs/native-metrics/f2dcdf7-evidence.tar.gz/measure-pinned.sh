#!/usr/bin/env bash
set -euo pipefail
repo=/home/tim/Projects/llm-forge
rev=f2dcdf776e3cb167006bf5bdb20cd31c165cfe1f
short=f2dcdf7
out=/tmp/forge-native-metrics/${short}-archive-evidence
snap="$out/source"
mkdir -p "$snap"
cd "$repo"
git archive "$rev" | tar -x -C "$snap"
git rev-parse "$rev" > "$out/commit.txt"
git ls-tree -r -z --name-only "$rev" > "$out/tracked.paths0"
: > "$out/all-source.paths0"
: > "$out/production-source.paths0"
: > "$out/test-source.paths0"
while IFS= read -r -d '' p; do
  case "$p" in *.py|*.rs|*.sh) ;; *) continue ;; esac
  case "$p" in
    docs/*|research/*|target/*|*/target/*|build/*|*/build/*|dist/*|*/dist/*|.venv/*|*/.venv/*) continue ;;
  esac
  printf '%s\0' "$p" >> "$out/all-source.paths0"
  is_test=0
  case "/$p/" in */tests/*|*/testdata/*) is_test=1;; esac
  case "$p" in *_tests.rs|*/tests.rs|conftest.py|*/conftest.py|test_*.py|*/test_*.py|*_test.py) is_test=1;; esac
  if [[ "$is_test" == 1 ]]; then
    printf '%s\0' "$p" >> "$out/test-source.paths0"
  elif [[ "$p" != native/forge/examples/* ]]; then
    printf '%s\0' "$p" >> "$out/production-source.paths0"
  fi
done < "$out/tracked.paths0"
(
  cd "$snap"
  while IFS= read -r -d '' p; do sha256sum -- "$p"; done < <(cat "$out/all-source.paths0")
) > "$out/source-content-sha256.txt"
sha256sum "$out"/{all-source,production-source,test-source}.paths0 > "$out/path-manifest-sha256.txt"
/tmp/forge-native-metrics/syn-split/target/release/forge-native-metric-split \
  "$snap" "$out/production-source.paths0" "$out/inline-prod" "$out/inline-test" "$out/inline-ranges.tsv" \
  > "$out/split-summary.txt"
cut -f1 "$out/inline-ranges.tsv" | sort -u | tr '\n' '\0' > "$out/inline-rust-paths.paths0"
(
  cd "$snap"
  xargs -0 /tmp/forge-native-metrics/bin/tokei --no-ignore --output json < "$out/production-source.paths0" > "$out/production-raw-tokei.json"
  xargs -0 /tmp/forge-native-metrics/bin/tokei --no-ignore --output json < "$out/test-source.paths0" > "$out/test-raw-tokei.json"
  xargs -0 /tmp/forge-native-metrics/bin/tokei --no-ignore --output json < "$out/all-source.paths0" > "$out/all-raw-tokei.json"
  xargs -0 /tmp/forge-native-metrics/bin/tokei --no-ignore --output json < "$out/inline-rust-paths.paths0" > "$out/inline-original-tokei.json"
  find "$out/inline-prod" -type f -name '*.rs' -print0 | xargs -0 /tmp/forge-native-metrics/bin/tokei --no-ignore --output json > "$out/inline-masked-prod-tokei.json"
)
cp /tmp/forge-native-metrics/syn-split/Cargo.toml "$out/syn-split-Cargo.toml"
cp /tmp/forge-native-metrics/syn-split/Cargo.lock "$out/syn-split-Cargo.lock"
cp /tmp/forge-native-metrics/syn-split/src/main.rs "$out/syn-split-source.rs"
{
  printf 'commit=%s\n' "$rev"
  printf 'tokei='; /tmp/forge-native-metrics/bin/tokei --version
  sha256sum /tmp/forge-native-metrics/bin/tokei
  sha256sum /tmp/forge-native-metrics/syn-split/target/release/forge-native-metric-split
} > "$out/tool-versions.txt"
count(){ jq -r --arg lang "$2" '.[$lang].code // 0' "$1"; }
P=$(count "$out/production-raw-tokei.json" Python)
RRAW=$(count "$out/production-raw-tokei.json" Rust)
S=$(count "$out/production-raw-tokei.json" Shell)
TP=$(count "$out/test-raw-tokei.json" Python)
TRSEP=$(count "$out/test-raw-tokei.json" Rust)
INLINE_ORIG=$(count "$out/inline-original-tokei.json" Rust)
INLINE_MASK=$(count "$out/inline-masked-prod-tokei.json" Rust)
INLINE=$((INLINE_ORIG-INLINE_MASK))
R=$((RRAW-INLINE))
TR=$((TRSEP+INLINE))
ALLP=$(count "$out/all-raw-tokei.json" Python)
ALLR=$(count "$out/all-raw-tokei.json" Rust)
ALLS=$(count "$out/all-raw-tokei.json" Shell)
PROD_SHARE=$(awk -v r="$R" -v p="$P" -v s="$S" 'BEGIN{printf "%.4f",100*r/(p+r+s)}')
TEST_SHARE=$(awk -v r="$TR" -v p="$TP" 'BEGIN{printf "%.4f",100*r/(p+r)}')
{
 printf 'production_files=%s\n' "$(tr -cd '\0' < "$out/production-source.paths0" | wc -c)"
 printf 'test_files=%s\n' "$(tr -cd '\0' < "$out/test-source.paths0" | wc -c)"
 printf 'all_source_files=%s\n' "$(tr -cd '\0' < "$out/all-source.paths0" | wc -c)"
 printf 'production_python=%s\nproduction_rust_inline_raw=%s\nproduction_inline_test_delta=%s\nproduction_rust=%s\nproduction_shell=%s\nproduction_native_percent=%s\n' "$P" "$RRAW" "$INLINE" "$R" "$S" "$PROD_SHARE"
 printf 'test_python=%s\ntest_rust_separate=%s\ntest_rust_inline=%s\ntest_rust=%s\ntest_rust_percent=%s\n' "$TP" "$TRSEP" "$INLINE" "$TR" "$TEST_SHARE"
 printf 'all_python=%s\nall_rust=%s\nall_shell=%s\n' "$ALLP" "$ALLR" "$ALLS"
} > "$out/metrics.txt"
(
 cd "$out"
 sha256sum source-content-sha256.txt all-source.paths0 production-source.paths0 test-source.paths0 inline-ranges.tsv inline-rust-paths.paths0
) > "$out/evidence-input-hashes.txt"
